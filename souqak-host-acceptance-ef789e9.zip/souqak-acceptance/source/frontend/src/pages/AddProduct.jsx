import React, { useEffect, useState, useRef } from "react";
import imageCompression from "browser-image-compression";
import { normalizeImageUploadFile } from "../lib/imageCompression.js";
import { useApi } from "../api/axios.js";
import { useGovernorates } from "../hooks/useGovernorates.js";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useAuth } from "../store/AuthContext.jsx";
import { t } from "../i18n/index.js";
import CategorySelect from "../components/CategorySelect.jsx";
import CategoryAttributeFields from "../components/CategoryAttributeFields.jsx";
import { isConditionEnabled } from "../lib/categoryHelpers.js";
import { useCategoryAttributeApi } from "../api/categoryAttributes.js";
import MobileSelect from "../components/MobileSelect.jsx";
import { useBrokerageApi } from "../api/brokerage.js";
import { useBrokerageStatus } from "../store/BrokerageStatusContext.jsx";
import { AD_COMMISSION_ENABLED } from "../config/commission.js";
import { getStoreCategoriesForActivity } from "../utils/storeCategories.js";
import CurrencyCalculator from "../components/CurrencyCalculator.jsx";
import SmartProgress from "../components/SmartProgress.jsx";
import { calculateAdProgress, getAdProgressMessage } from "../utils/adProgress.js";

export default function AddProduct() {
  const { data: governoratesData = [] } = useGovernorates();
  const api = useApi();
  const brokerageApi = useBrokerageApi();
  const { enabled: brokerageEnabled } = useBrokerageStatus();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const storeProductMode = searchParams.get("storeProduct") === "1";
  const storeType = searchParams.get("storeType") === "family-production" ? "family-production" : "store";
  const storeDashboardPath = storeType === "family-production" ? "/my-family-production" : "/my-store";
  const adType = storeProductMode ? "sell" : searchParams.get("type") || "sell"; // 'sell' or 'order'
  const [isAvailable, setIsAvailable] = useState(true);
  const [isAvailableForDelivery, setIsAvailableForDelivery] = useState(false);
  const [supportsDelivery, setSupportsDelivery] = useState(false);
  const [supportsDiscounts, setSupportsDiscounts] = useState(false);
  const [supportsInventory, setSupportsInventory] = useState(false);
  const [inventoryEnabled, setInventoryEnabled] = useState(false);
  const [stockQuantity, setStockQuantity] = useState("0");
  const [discountEnabled, setDiscountEnabled] = useState(false);
  const [discountType, setDiscountType] = useState("percentage");
  const [discountValue, setDiscountValue] = useState("10");
  
  const categoryAttributeApi = useCategoryAttributeApi();
  const { user } = useAuth();
  
  // Brokerage Campaign State
  const [enableBrokerage, setEnableBrokerage] = useState(false);
  const [brokerageType, setBrokerageType] = useState("AUTO_JOIN"); // AUTO_JOIN, MANUAL_APPROVAL, SINGLE_BROKER, LIMITED
  const [brokerageRewardType, setBrokerageRewardType] = useState("FIXED"); // FIXED, PERCENTAGE
  const [brokerageRewardValue, setBrokerageRewardValue] = useState("");
  const [brokerageMaxBrokers, setBrokerageMaxBrokers] = useState("");
  const [brokerageExpiresAt, setBrokerageExpiresAt] = useState("");
  
  // Form Refs for scrolling
  const formRefs = {
    title: useRef(null),
    categoryId: useRef(null),
    governorateId: useRef(null),
    cityId: useRef(null),
    price: useRef(null),
    files: useRef(null),
  };
  const formRef = useRef(null);
  const errorRef = useRef(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState("");
  const [currency, setCurrency] = useState("YER_ADEN");
  const [governorateId, setGovernorateId] = useState("");
  const [cityId, setCityId] = useState("");
  const [files, setFiles] = useState([]);
  const [previews, setPreviews] = useState([]);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [phoneVerificationRequired, setPhoneVerificationRequired] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [isPreparingImages, setIsPreparingImages] = useState(false);
  const [prepareStatus, setPrepareStatus] = useState("");
  const [governorates, setGovernorates] = useState([]);
  const [cities, setCities] = useState([]);
  const [attrs, setAttrs] = useState({});
  const [showAfterPublishModal, setShowAfterPublishModal] = useState(false);
  const [condition, setCondition] = useState("used");
  const [selectedTags, setSelectedTags] = useState([]);
  const [categoryId, setCategoryId] = useState("");
  const [availableTags, setAvailableTags] = useState([]);
  const [showPhone, setShowPhone] = useState(false);
  const [phone, setPhone] = useState("");
  const [showWhatsApp, setShowWhatsApp] = useState(false);
  const [whatsapp, setWhatsApp] = useState("");
  const [negotiable, setNegotiable] = useState(false);
  const [priceOnContact, setPriceOnContact] = useState(false);
  const [showConsent, setShowConsent] = useState(AD_COMMISSION_ENABLED && adType === "sell" && !storeProductMode);
  const [consentEnabledAt, setConsentEnabledAt] = useState(0);
  const [commissionAgreed, setCommissionAgreed] = useState(!AD_COMMISSION_ENABLED || adType === "order" || storeProductMode);
  const [nowTs, setNowTs] = useState(Date.now());
  const [blockErr, setBlockErr] = useState("");
  const [pendingCommissionPayLink, setPendingCommissionPayLink] = useState("/seller/commissions");
  const [selectedMainCategoryName, setSelectedMainCategoryName] = useState("");
  const [isStoreProduct, setIsStoreProduct] = useState(storeProductMode);
  const [storeCategories, setStoreCategories] = useState([]);

  useEffect(() => {
    if (!err) return undefined;

    const frameId = window.requestAnimationFrame(() => {
      const target = errorRef.current || formRef.current;
      if (!target) return;
      target.scrollIntoView({ behavior: "smooth", block: "center" });
      if (errorRef.current) errorRef.current.focus({ preventScroll: true });
    });

    return () => window.cancelAnimationFrame(frameId);
  }, [err]);

  const CONDITION_ENABLED_CATEGORIES = [
    "السيارات",
    "المركبات",
    "مركبات",
    "شاحنات",
    "دراجات نارية",
    "الالكترونيات",
    "أثاث",
    "طلبات الشراء",
    "ملابس وأزياء",
    "ألعاب وترفية",
    "أدوات ومعدات",
    "مركبات خاصة",
    "أدوات مكتبية",
    "مستلزمات رياضية",
    "الصحة والجمال",
    "الكتب والمجلات",
    "آلات موسيقية",
    "أجهزة منزلية",
    "اجهزة منزلية",
    "الأجهزة المنزلية",
    "اجهزه منزليه"
  ];
  // Category state for 'order' type (Level 2 & 3 selection)
  const [mainCatsForOrder, setMainCatsForOrder] = useState([]);
  const [subCatsForOrder, setSubCatsForOrder] = useState([]);
  const [orderMainCategoryId, setOrderMainCategoryId] = useState("");
  const [orderSubCategoryId, setOrderSubCategoryId] = useState("");
  const [purchaseOrderCatId, setPurchaseOrderCatId] = useState("");

  // Welcome Promotion
  const [promoEligibility, setPromoEligibility] = useState({ eligible: false, durationHours: 6 });

  const checkPromo = async () => {
    try {
      const res = await api.get("/ads/welcome-promotion/eligibility");
      setPromoEligibility(res.data);
    } catch {}
  };

  useEffect(() => {
    if (!storeProductMode) checkPromo();
  }, [storeProductMode]);

  useEffect(() => {
    if (!storeProductMode) return;
    Promise.all([
      api.get("/stores/me", { params: { storeType } }),
      api.get("/stores/activities", { params: { type: storeType } })
    ]).then(([{ data: store }, { data: activities }]) => {
      if (store?.status === "active" && store?.subscriptionStatus === "active") {
        setStoreCategories(getStoreCategoriesForActivity(store, activities));
      }
      setSupportsDelivery(store?.status === "active"
        && store?.subscriptionStatus === "active"
        && store?.subscription?.plan?.features?.delivery === true);
      setSupportsDiscounts(store?.status === "active"
        && store?.subscriptionStatus === "active"
        && store?.subscription?.plan?.features?.discounts === true);
      setSupportsInventory(store?.status === "active"
        && store?.subscriptionStatus === "active"
        && store?.subscription?.plan?.features?.inventory === true);
    }).catch(() => {});
  }, [api, storeProductMode, storeType]);

  useEffect(() => {
    setSelectedMainCategoryName("");
    setCategoryId("");
  }, [adType]);

  // Handle 'Purchase Orders' category for 'order' type
  useEffect(() => {
    if (adType === "order") {
      api.get("/categories").then(res => {
        const cats = res.data || [];
        const purchaseOrderCat = cats.find(c => c.slug === "purchase-orders" || c.name === "طلبات الشراء");
        if (purchaseOrderCat) {
          setPurchaseOrderCatId(purchaseOrderCat._id || purchaseOrderCat.id);
          // Initial category is 'Purchase Orders' but user must choose sub-categories
          setCategoryId(purchaseOrderCat._id || purchaseOrderCat.id);
          setSelectedMainCategoryName("طلبات الشراء");
        }
        // Filter out 'Purchase Orders' to show as level 2 options
        const filteredMain = cats.filter(c => c.slug !== "purchase-orders" && c.name !== "طلبات الشراء");
        setMainCatsForOrder(filteredMain);
      });
    }
  }, [adType, api]);

  // Load sub-categories for 'order' type Level 3
  useEffect(() => {
    if (adType === "order" && orderMainCategoryId) {
      api.get(`/categories/${orderMainCategoryId}/children`).then(res => {
        setSubCatsForOrder(res.data || []);
      });
    } else {
      setSubCatsForOrder([]);
    }
  }, [adType, orderMainCategoryId, api]);

  const handleOrderMainCategoryChange = (e) => {
    const val = e.target.value;
    setOrderMainCategoryId(val);
    setOrderSubCategoryId(""); // Reset level 3
    if (val) {
      // If user selected a main category, use it for now
      setCategoryId(val);
      const cat = mainCatsForOrder.find(c => (c._id || c.id) === val);
      setSelectedMainCategoryName(cat?.name || "");
    } else {
      // Fallback to purchase order cat if nothing selected
      setCategoryId(purchaseOrderCatId);
      setSelectedMainCategoryName("طلبات الشراء");
    }
    setValidationErrors(prev => ({ ...prev, categoryId: null }));
  };

  const handleOrderSubCategoryChange = (e) => {
    const val = e.target.value;
    setOrderSubCategoryId(val);
    if (val) {
      setCategoryId(val);
    } else if (orderMainCategoryId) {
      setCategoryId(orderMainCategoryId);
    }
    setValidationErrors(prev => ({ ...prev, categoryId: null }));
  };

  // Dynamic category attributes
  const [categoryAttributes, setCategoryAttributes] = useState([]);
  const [categoryAttributesReady, setCategoryAttributesReady] = useState(true);
  const [attributeValues, setAttributeValues] = useState({});

  const handleFiles = (e) => {
    const fAll = Array.from(e.target.files || []);
    const fileKey = (file) => `${file.name}-${file.size}-${file.lastModified}`;

    setFiles((currentFiles) => {
      const existingKeys = new Set(currentFiles.map(fileKey));
      const newFiles = fAll.filter((file) => !existingKeys.has(fileKey(file)));
      const nextFiles = [...currentFiles, ...newFiles].slice(0, 10);

      if (currentFiles.length + newFiles.length > 10) {
        setErr("يمكن رفع حد أقصى 10 صور فقط");
      } else {
        setErr("");
        setValidationErrors(prev => ({ ...prev, files: null }));
      }

      return nextFiles;
    });

    e.target.value = "";
  };

  const removeFile = (indexToRemove) => {
    setFiles((currentFiles) => currentFiles.filter((_, index) => index !== indexToRemove));
  };

  useEffect(() => {
    const nextPreviews = files.map((file) => URL.createObjectURL(file));
    setPreviews(nextPreviews);

    return () => {
      nextPreviews.forEach((url) => URL.revokeObjectURL(url));
    };
  }, [files]);

  const isWebPSupported = () => {
    const canvas = document.createElement("canvas");
    return canvas.toDataURL("image/webp").startsWith("data:image/webp");
  };

  const prepareFilesForUpload = async (selectedFiles) => {
    if (!selectedFiles?.length) return [];

    const preparedFiles = [];
    const webpSupported = isWebPSupported();

    for (let index = 0; index < selectedFiles.length; index += 1) {
      const file = selectedFiles[index];
      const isHeic = /heic|heif/i.test(file.type || "");
      const shouldCompress = file.size > 500 * 1024 || isHeic;

      setPrepareStatus(`جاري تجهيز الصور ${index + 1} من ${selectedFiles.length}...`);

      if (!shouldCompress) {
        preparedFiles.push(file);
        continue;
      }

      try {
        const compressed = await imageCompression(file, {
          maxSizeMB: 0.9,
          maxWidthOrHeight: 1600,
          maxIteration: 10,
          useWebWorker: true,
          initialQuality: 0.82,
          fileType: webpSupported ? "image/webp" : "image/jpeg",
          alwaysKeepResolution: false,
          onProgress: (progress) => {
            setPrepareStatus(`جاري تجهيز الصور ${index + 1} من ${selectedFiles.length} (${Math.round(progress)}%)...`);
          }
        });

        preparedFiles.push(compressed);
      } catch (error) {
        console.error("Image compression failed for file:", file.name, error);
        throw new Error("تعذر تجهيز إحدى الصور. يرجى اختيار صورة أخرى أو تحويلها إلى JPG/PNG ثم المحاولة مرة أخرى.");
      }
    }

    return preparedFiles.map(normalizeImageUploadFile);
  };

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/tags");
        setAvailableTags(res.data || []);
      } catch {
        setAvailableTags([]);
      }
    })();
  }, []);

  useEffect(() => {
    if (AD_COMMISSION_ENABLED && adType === "sell" && !isStoreProduct && showConsent) {
      const start = Date.now();
      setConsentEnabledAt(start + 5000);
      const int = setInterval(() => setNowTs(Date.now()), 200);
      return () => clearInterval(int);
    }
  }, [showConsent, adType, isStoreProduct]);

  useEffect(() => {
    (async () => {
      try {
        setGovernorates(governoratesData);
      } catch {
        setGovernorates([]);
      }
    })();
  }, [governoratesData]);

  useEffect(() => {
    if (user) {
      api.get("/commissions/status-summary")
        .then(res => {
          const blockingCount = Number(res.data?.blockingCount || 0);
          const firstUnpaidAdId = res.data?.firstUnpaidAdId?._id || res.data?.firstUnpaidAdId || null;

          if (blockingCount > 0) {
            setBlockErr("لا يمكنك إضافة إعلان حتى تقوم بدفع عمولة المنصة.");
            setPendingCommissionPayLink(
              firstUnpaidAdId ? `/commission/pay?adId=${firstUnpaidAdId}` : "/seller/commissions"
            );
          } else {
            setBlockErr("");
            setPendingCommissionPayLink("/seller/commissions");
          }
        })
        .catch(() => {
          setBlockErr("");
          setPendingCommissionPayLink("/seller/commissions");
        });
    }
  }, [user, api]);

  useEffect(() => {
    if (!governorateId) {
      setCities([]);
      setCityId("");
      return;
    }
    (async () => {
      try {
        const res = await api.get(`/cities?governorateId=${governorateId}&active=true`);
        setCities(res.data || []);
      } catch {
        setCities([]);
      }
    })();
  }, [governorateId]);

  // Load category attributes when category changes
  useEffect(() => {
    if (!categoryId || (!isStoreProduct && adType !== "sell")) {
      setCategoryAttributes([]);
      setAttributeValues({});
      setCategoryAttributesReady(true);
      return;
    }
    let cancelled = false;
    setCategoryAttributes([]);
    setAttributeValues({});
    setCategoryAttributesReady(false);
    (async () => {
      try {
        const res = await categoryAttributeApi.getCategoryAttributes(categoryId, { includeAncestors: !isStoreProduct });
        if (!cancelled) {
          setCategoryAttributes(res.data || []);
          setCategoryAttributesReady(true);
        }
      } catch (error) {
        console.error("Error loading category attributes:", error);
        if (!cancelled) setCategoryAttributes([]);
      }
    })();
    return () => { cancelled = true; };
  }, [categoryId, isStoreProduct]);

  const handleCategoryChange = (newCategoryId) => {
    setCategoryId(newCategoryId);
    setCategoryAttributes([]);
    setAttributeValues({});
    setCategoryAttributesReady(!newCategoryId || (!isStoreProduct && adType !== "sell"));
    setValidationErrors(prev => ({ ...prev, categoryId: null }));
  };

  const handleAttributeChange = (attributeId, value) => {
    setAttributeValues(prev => ({
      ...prev,
      [attributeId]: value
    }));
  };

  const scrollToFirstError = (errors) => {
    const firstErrorKey = Object.keys(errors).find(key => errors[key]);
    if (firstErrorKey && formRefs[firstErrorKey]?.current) {
      formRefs[firstErrorKey].current.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };

  const validateForm = () => {
    const errors = {};
    if (!title.trim()) errors.title = isStoreProduct ? "اسم المنتج مطلوب" : "عنوان المنتج مطلوب";
    if (adType === "order") {
      if (!orderMainCategoryId) errors.categoryId = "يرجى اختيار الفئة";
    } else {
      if (!categoryId) errors.categoryId = "الفئة مطلوبة";
    }
    if (!isStoreProduct) {
      if (!governorateId) errors.governorateId = "المحافظة مطلوبة";
      if (!cityId) errors.cityId = "المدينة مطلوبة";
    }
    
    // For 'order' type, price and images are optional
    if (adType !== "order") {
      if ((isStoreProduct || !priceOnContact) && (!price || Number(price) <= 0)) errors.price = "يرجى إدخال السعر";
      if (!isStoreProduct && files.length === 0) errors.files = "يجب رفع صورة واحدة على الأقل";
    }
    if (isStoreProduct && supportsDiscounts && discountEnabled
      && (discountType === "percentage"
        ? (!Number.isInteger(Number(discountValue)) || Number(discountValue) < 1 || Number(discountValue) > 99)
        : (!Number.isFinite(Number(discountValue)) || Number(discountValue) <= 0 || Number(discountValue) > Number(price)))) {
      errors.discountValue = discountType === "percentage"
        ? "أدخل نسبة خصم صحيحة من 1 إلى 99%."
        : "أدخل مبلغ خصم أكبر من صفر ولا يتجاوز سعر المنتج.";
    }
    if (isStoreProduct && supportsInventory && inventoryEnabled
      && (!stockQuantity.trim() || !Number.isSafeInteger(Number(stockQuantity)) || Number(stockQuantity) < 0)) {
      errors.stockQuantity = "أدخل كمية مخزون صحيحة (عدد صحيح لا يقل عن صفر).";
    }

    setValidationErrors(errors);
    if (Object.keys(errors).length > 0) {
      scrollToFirstError(errors);
      setErr(errors.discountValue || errors.stockQuantity || (isStoreProduct ? "يرجى تعبئة بيانات المنتج المطلوبة." : "يرجى تعبئة الحقول المطلوبة قبل نشر الإعلان"));
      return false;
    }
    return true;
  };

  const submit = async (e) => {
    e.preventDefault();
    setMsg("");
    setErr("");
    setPhoneVerificationRequired(false);
    setValidationErrors({});

    if (!user) {
      setErr("يرجى تسجيل الدخول أولاً");
      return;
    }
    if (!user.phoneVerifiedAt) {
      setPhoneVerificationRequired(true);
      setErr("يلزم توثيق رقم الهاتف قبل نشر الإعلان.");
      return;
    }
    if (AD_COMMISSION_ENABLED && !commissionAgreed) {
      setErr("يجب الموافقة على التعهد بدفع عمولة المنصة 1% بعد البيع");
      return;
    }
    
    if (!validateForm()) return;

    setLoading(true);
    setPrepareStatus("");
    let preparedFiles = [];

    try {
      if ((files || []).length > 0) {
        setIsPreparingImages(true);
        setPrepareStatus("جاري تجهيز الصور...");
        preparedFiles = await prepareFilesForUpload(files);
        setPrepareStatus(isStoreProduct ? "جارٍ إضافة المنتج..." : "جاري نشر الإعلان...");
      }

      const form = new FormData();
      form.append("title", title);
      form.append("description", description);
      form.append("price", Number(price || 0));
      form.append("currency", currency);
      if (!isStoreProduct) {
        form.append("governorateId", governorateId);
        form.append("cityId", cityId);
      }
      if (categoryId) form.append("categoryId", categoryId);
      form.append("adType", adType);
      if (isStoreProduct) {
        form.append("storeProduct", "true");
        form.append("storeType", storeType);
        form.append("isAvailable", String(isAvailable));
        form.append("isAvailableForDelivery", String(isAvailableForDelivery));
        if (supportsDiscounts) {
          form.append("discountEnabled", String(discountEnabled));
          form.append("discountType", discountType);
          form.append("discountValue", discountValue);
        }
        if (supportsInventory) {
          form.append("inventoryEnabled", String(inventoryEnabled));
          form.append("stockQuantity", stockQuantity);
        }
      }

      if (!isStoreProduct) form.append("condition", condition);
      form.append("negotiable", negotiable ? "true" : "false");
      if (!isStoreProduct) form.append("priceOnContact", priceOnContact ? "true" : "false");

      // Optional contact info: only send if seller really wants to show it
      const normalizedPhone = (phone || "").trim();
      const normalizedWhatsApp = (whatsapp || "").trim();
      if (!isStoreProduct && showPhone && normalizedPhone) {
        form.append("showPhone", true);
        form.append("phone", normalizedPhone);
      }
      if (!isStoreProduct && showWhatsApp && normalizedWhatsApp) {
        form.append("showWhatsApp", true);
        form.append("whatsapp", normalizedWhatsApp);
      }
      if (!isStoreProduct) selectedTags.forEach((tagId) => form.append("tags", tagId));
      preparedFiles.forEach((file) => form.append("images", file));
      
      // Add category attributes
      const attributes = (isStoreProduct
        ? categoryAttributes.map((attribute) => {
            const attributeId = String(attribute.id || attribute._id);
            return { attributeId, value: attributeValues[attributeId] };
          })
        : Object.entries(attributeValues).map(([attributeId, value]) => ({ attributeId, value }))
      ).filter(({ value }) => value !== undefined && value !== null && value !== "" && !(Array.isArray(value) && value.length === 0))
        .map(({ attributeId, value }) => ({ attributeId, value: Array.isArray(value) ? value.join(",") : String(value) }));
      
      if (isStoreProduct || attributes.length > 0) {
        form.append("attributes", JSON.stringify(attributes));
      }
      
      const res = await api.post("/ads", form);
    const created = res.data;
    if (created?._id) {
      // Create brokerage campaign if enabled
      if (enableBrokerage) {
        try {
          await brokerageApi.createCampaign({
            adId: created._id,
            type: brokerageType,
            maxBrokerCount: brokerageMaxBrokers ? Number(brokerageMaxBrokers) : undefined,
            rewardType: brokerageRewardType,
            rewardValue: Number(brokerageRewardValue),
            rewardCurrency: currency,
            expiresAt: brokerageExpiresAt ? new Date(brokerageExpiresAt) : undefined
          });
        } catch (err) {
          console.error("Failed to create brokerage campaign:", err);
        }
      }
      
      setMsg(isStoreProduct ? "✅ تمت إضافة المنتج بنجاح" : "✅ تم نشر الإعلان بنجاح");
      setShowAfterPublishModal(true);
    }
    } catch (e) {
      console.error("Ad creation failed:", e);
      const status = e?.response?.status;
      const data = e?.response?.data;

      if (e?.message === "تعذر تجهيز إحدى الصور. يرجى اختيار صورة أخرى أو صورة بحجم أصغر.") {
        setErr(e.message);
      } else if (status === 401) {
        setErr("يرجى تسجيل الدخول أولاً");
      } else if (status === 403 && data?.code === "PHONE_VERIFICATION_REQUIRED") {
        setPhoneVerificationRequired(true);
        setErr("يلزم توثيق رقم الهاتف قبل نشر الإعلان.");
      } else if (status === 403) {
        setErr("هذا الإجراء متاح للبائعين فقط");
      } else if (status === 400 && data) {
        let errorMsg = "";
        if (Array.isArray(data.details) && data.details.length > 0 && data.details[0]?.message) {
          errorMsg = data.details[0].message;
        } else if (typeof data.error === "string") {
          errorMsg = data.error;
        }

        if (/[a-zA-Z]/.test(errorMsg)) {
          const lowerError = errorMsg.toLowerCase();
          if (lowerError.includes("is required")) {
            setErr("يرجى تعبئة جميع الحقول المطلوبة.");
          } else if (lowerError.includes("must be a number")) {
            setErr("يجب أن تكون القيمة عدداً.");
          } else if (lowerError.includes("limit")) {
            setErr("لقد تجاوزت الحد المسموح به.");
          } else if (lowerError.includes("image") || lowerError.includes("file")) {
            setErr("هناك مشكلة في الصور المرفوعة، يرجى التأكد من صيغة الصور وحجمها.");
          } else if (lowerError.includes("attributes")) {
            setErr("يرجى التأكد من تعبئة خصائص الفئة بشكل صحيح.");
          } else {
            setErr(`خطأ في البيانات: ${errorMsg}`);
          }
        } else {
          setErr(errorMsg || t("addProduct.error"));
        }
      } else if (e?.code === "ERR_NETWORK") {
        setErr("فشل الاتصال بالشبكة أثناء رفع الإعلان. يرجى التحقق من الإنترنت ثم المحاولة مرة أخرى.");
      } else {
        setErr(t("addProduct.error"));
      }
    } finally {
      setLoading(false);
      setIsPreparingImages(false);
      setPrepareStatus("");
    }
  };

  if (blockErr) {
    return (
      <div className="mx-auto max-w-xl px-3 py-6 sm:px-4 sm:py-12">
        <div className="rounded-3xl bg-white border border-red-100 p-5 text-center shadow-2xl shadow-red-50 sm:rounded-[2.5rem] sm:p-10">
          <div className="mb-4 flex justify-center sm:mb-6">
            <div className="rounded-full bg-red-50 p-4 ring-8 ring-red-50/50">
              <svg className="h-12 w-12 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
              </svg>
            </div>
          </div>
          <h2 className="mb-3 text-2xl font-black text-gray-900 sm:mb-4">{isStoreProduct ? "إضافة المنتج محجوبة" : "نشر الإعلان محجوب"}</h2>
          <p className="mb-3 text-gray-600 font-bold leading-relaxed">{blockErr}</p>
          <p className="mb-5 text-sm font-bold leading-relaxed text-amber-700 sm:mb-8">
            بعد الموافقة على طلب الدفع من الإدارة، سيتم تفعيل إضافة الإعلان تلقائيًا.
          </p>
          <div className="flex flex-col gap-3">
            <Link
              to={pendingCommissionPayLink}
              className="w-full rounded-2xl bg-brand-600 py-4 text-base font-black text-white transition-all hover:bg-brand-700 shadow-xl shadow-brand-100"
            >
              دفع الآن
            </Link>
            <Link
              to="/"
              className="w-full rounded-2xl border border-gray-200 bg-white py-3 text-center text-sm font-bold text-gray-500 hover:bg-gray-50"
            >
              العودة للرئيسية
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Consent - Only show for sell type
  if (AD_COMMISSION_ENABLED && adType === "sell" && !isStoreProduct && showConsent) {
    return (
      <div className="min-h-[calc(100vh-70px)] bg-white flex flex-col px-4 py-4 sm:p-8">
        <div className="w-full max-w-3xl mx-auto flex-1 flex flex-col justify-center">
          <div className="mb-3 text-center sm:mb-6 sm:text-right">
            <h2 className="text-2xl font-black text-gray-900 sm:text-3xl leading-tight">ميثاق الأمانة والعمولة</h2>
            <div className="mt-3 h-1 w-16 bg-blue-600 mx-auto sm:ml-auto sm:mr-0 rounded-full" />
          </div>

          <div className="space-y-3 text-right sm:space-y-6">
            <div className="space-y-2 bg-gray-50/50 p-4 sm:p-6 rounded-2xl border border-gray-100">
              <p className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] text-center sm:text-right">بِسْمِ اللَّهِ الرَّحْمَنِ الرَّحِيمِ</p>
              <p className="text-base leading-relaxed text-gray-700 sm:text-xl text-center sm:text-right">
                قال الله تعالى: <span className="font-black text-gray-900 text-lg sm:text-2xl block mt-2 mb-1">« يَا أَيُّهَا الَّذِينَ آمَنُوا أَوْفُوا بِالْعُقُودِ »</span> 
                <span className="text-xs text-gray-400 font-medium">صدق الله العظيم</span>
              </p>
            </div>

            <div className="space-y-2 sm:space-y-4 sm:pt-2">
              <label className="group flex cursor-pointer items-start gap-3 sm:gap-4 p-2">
                <div className="relative mt-1 flex-shrink-0">
                  <input
                    type="checkbox"
                    className="peer h-6 w-6 sm:h-7 sm:w-7 cursor-pointer appearance-none rounded-lg border-2 border-gray-300 transition-all checked:border-blue-600 checked:bg-blue-600"
                    checked={commissionAgreed}
                    onChange={(e) => setCommissionAgreed(e.target.checked)}
                  />
                  <svg className="absolute left-1 top-1 sm:left-1.5 sm:top-1.5 h-4 w-4 scale-0 text-white transition-transform peer-checked:scale-100" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={4} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
                <div className="flex-1 space-y-2">
                  <span className="block text-sm font-black leading-relaxed text-gray-800 group-hover:text-gray-900 sm:text-lg">
                    أقر وأتعهد بالأمانة التامة في البيع، وألتزم بدفع عمولة المنصة المقدرة بـ 1% من قيمة البيع، سواء تم البيع مباشرة عبر الموقع أو كان الموقع سبباً في ذلك.
                  </span>
                  <p className="text-sm font-bold leading-relaxed text-gray-600 sm:text-base">
                    كما ألتزم بتحويل العمولة فور استلام ثمن السلعة، أو خلال مدة لا تتجاوز 10 أيام عمل.
                  </p>
                </div>
              </label>
            </div>

            <div className="space-y-2 rounded-2xl border-2 border-amber-200 bg-amber-50 p-4 sm:p-6 text-right">
              <h4 className="text-base sm:text-lg font-black text-amber-800 flex items-center gap-2 justify-start mb-2">
                <div className="rounded-full bg-amber-200 p-1.5">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                ملاحظة هامة بشأن الرسوم
              </h4>
              <p className="text-sm leading-relaxed text-amber-900 sm:text-base font-bold">
                رسوم المنصة هي أمانة في ذمة المعلن (البائع)، ولا تبرأ ذمته منها إلا بعد سدادها للمنصة. 
                نحن نثق في أمانتكم لضمان استمرار تقديم الخدمة وتطويرها.
              </p>
              <div className="mt-3 inline-block rounded-xl bg-amber-200/50 px-4 py-2 text-xs sm:text-sm font-black text-amber-900 border border-amber-300/50">
                ملاحظة: إذا كانت العمولة أقل من 1000 ريال يمني (عدن) فيُستحب التصدق بها.
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-3 pt-4 pb-10 sm:pb-0">
              <button
                type="button"
                className="w-full sm:flex-1 rounded-xl bg-blue-600 py-4 sm:py-4 text-base font-black text-white transition-all active:scale-[0.98] hover:bg-blue-700 disabled:opacity-50 disabled:active:scale-100 shadow-lg shadow-blue-200"
                disabled={!commissionAgreed || nowTs < consentEnabledAt}
                onClick={() => setShowConsent(false)}
              >
                {nowTs < consentEnabledAt ? `يرجى القراءة (${Math.ceil((consentEnabledAt - nowTs) / 1000)} ثانية)` : "أتعهد بذلك وأوافق »"}
              </button>
              <Link
                to="/"
                className="w-full sm:w-auto sm:px-10 rounded-xl border-2 border-gray-200 bg-white py-4 sm:py-4 text-center text-base font-black text-gray-500 transition-all hover:bg-gray-50 hover:text-gray-700"
              >
                إلغاء
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  const progress = calculateAdProgress({
    mode: "add",
    isStoreProduct,
    adType,
    title,
    categoryId,
    orderMainCategoryId,
    governorateId,
    cityId,
    price,
    priceOnContact,
    files,
    description,
    showPhone,
    phone,
    showWhatsApp,
    whatsapp,
    categoryAttributes,
    categoryAttributesReady: !isStoreProduct || categoryAttributesReady,
    attributeValues,
    supportsDiscounts,
    discountEnabled,
    discountType,
    discountValue,
    supportsInventory,
    inventoryEnabled,
    stockQuantity
  });

  return (
    <div className="mx-auto mb-20 max-w-2xl ds-section p-4 sm:mb-0 sm:p-8">
      <h2 className="ds-title mb-6">{isStoreProduct ? "إضافة منتج" : adType === "order" ? "إضافة طلب شراء منتج" : t("addProduct.formTitle")}</h2>

      {/* Welcome Promotion Banner */}
      {promoEligibility.eligible && adType !== "order" && !isStoreProduct && (
        <div className="bg-gradient-to-r from-amber-400 to-orange-500 rounded-2xl p-3 mb-5 text-white shadow-xl shadow-orange-100 relative overflow-hidden group border-2 border-white sm:rounded-[2rem] sm:p-6 sm:mb-8 sm:border-4">
          <div className="absolute top-0 right-0 w-24 h-24 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl group-hover:scale-150 transition-transform duration-700 sm:w-32 sm:h-32"></div>
          <div className="relative flex flex-col sm:flex-row items-center gap-2.5 sm:gap-6">
            <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center text-xl shadow-inner backdrop-blur-sm sm:w-16 sm:h-16 sm:rounded-2xl sm:text-3xl">
              🎁
            </div>
            <div className="flex-1 text-center sm:text-right">
              <h3 className="text-sm font-black mb-0.5 sm:text-lg sm:mb-1">جرب التمييز مجاناً!</h3>
              <p className="text-orange-50 text-[11px] font-medium leading-snug sm:text-sm sm:leading-relaxed">
                يمكنك الآن تجربة ميزة التمييز <span className="bg-white/20 px-2 py-0.5 rounded-lg font-black text-white">مجاناً</span> لمدة {promoEligibility.durationHours} ساعات لأي إعلان تختاره.
              </p>
            </div>
            <Link 
              to="/seller/featured-ad" 
              className="px-4 py-1.5 bg-white text-orange-600 rounded-lg font-black text-[11px] shadow-lg hover:bg-orange-50 transition-colors sm:px-6 sm:py-2 sm:rounded-xl sm:text-sm"
            >
              اكتشف المزيد
            </Link>
          </div>
        </div>
      )}

      <form ref={formRef} onSubmit={submit} className="flex flex-col gap-6">
        {adType === "order" && (
          <div className="rounded-2xl bg-indigo-50 border border-indigo-100 p-4 mb-6">
            <p className="text-sm font-bold text-indigo-800">
              أنت الآن تقوم بإضافة "طلب شراء". سيظهر طلبك في قسم طلبات الشراء ليتمكن البائعون من التواصل معك وتوفير ما تحتاجه.
            </p>
          </div>
        )}
        <SmartProgress percent={progress.percent} message={getAdProgressMessage(progress)} />
        
        {msg && (
          <div className="sticky top-20 z-10 rounded-xl bg-green-50 border border-green-200 px-4 py-3 text-sm text-green-700 shadow-sm animate-in fade-in slide-in-from-top-4 duration-300">
            {msg}
          </div>
        )}
        {err && (
          <div ref={errorRef} role="alert" tabIndex={-1} className="rounded-xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-700 shadow-sm animate-in fade-in slide-in-from-top-4 duration-300">
            ⚠ {err}
            {phoneVerificationRequired && (
              <Link to="/verify-phone" className="mr-2 inline-block font-black underline">
                ابدأ توثيق رقم الهاتف
              </Link>
            )}
          </div>
        )}

        <div ref={formRefs.title} className="order-1 space-y-1">
        <label className="block text-sm font-bold text-gray-700">
          {isStoreProduct ? "اسم المنتج" : t("addProduct.labels.title")} <span className="text-red-500 mr-1">*</span>
        </label>
        <input 
          className={`ds-input ${validationErrors.title ? "border-red-500 ring-2 ring-red-100" : ""}`}
          placeholder={isStoreProduct ? "أدخل اسم المنتج" : t("addProduct.labels.titlePh")}
          value={title} 
          onChange={(e) => {
            const nextTitle = e.target.value.slice(0, 30);
            setTitle(nextTitle);
            if (nextTitle.trim()) setValidationErrors(prev => ({ ...prev, title: null }));
          }} 
          maxLength={30}
        />
        <div className="text-left text-xs font-bold text-gray-400" dir="ltr">{title.length}/30</div>
        {validationErrors.title && <p className="text-xs text-red-600 font-bold">{validationErrors.title}</p>}
      </div>
      
      <div ref={formRefs.categoryId} className="order-2 space-y-4">
        {!isStoreProduct && <label className="block text-sm font-bold text-gray-700">
          الفئة <span className="text-red-500 mr-1">*</span>
        </label>}
        <div className={validationErrors.categoryId ? "rounded-xl border-2 border-red-500 p-1 bg-red-50/30" : ""}>
          {adType === "order" ? (
            <div className="space-y-4">
              {/* Level 1: Fixed */}
              <div className="ds-input bg-gray-50 text-gray-500 font-bold cursor-not-allowed flex items-center justify-between">
                <span>طلبات الشراء</span>
                <span className="text-[10px] bg-indigo-100 text-indigo-700 px-2 py-0.5 rounded-full">فئة افتراضية</span>
              </div>

              {/* Level 2: Selection (Main Categories from Sell) */}
              <div className="animate-in slide-in-from-top-2 duration-200">
                <MobileSelect
                  label="اختر الفئة التي تطلب فيها"
                  value={orderMainCategoryId}
                  onChange={handleOrderMainCategoryChange}
                  required={true}
                  options={mainCatsForOrder.map(c => ({ value: c._id || c.id, label: c.name }))}
                  placeholder="اختر الفئة..."
                />
              </div>

              {/* Level 3: Selection (Sub Categories) */}
              {orderMainCategoryId && subCatsForOrder.length > 0 && (
                <div className="animate-in slide-in-from-top-2 duration-300">
                  <MobileSelect
                    label="اختر القسم"
                    value={orderSubCategoryId}
                    onChange={handleOrderSubCategoryChange}
                    required={false}
                    options={subCatsForOrder.map(c => ({ value: c._id || c.id, label: c.name }))}
                    placeholder="اختر القسم (اختياري)..."
                  />
                </div>
              )}
            </div>
          ) : isStoreProduct ? (
            <MobileSelect
              label="تصنيف المنتج"
              value={categoryId}
              onChange={(event) => handleCategoryChange(event.target.value)}
              required={true}
              options={storeCategories.map((category) => ({ value: category._id || category.id || category, label: category.name || "تصنيف المنتج" }))}
              placeholder={storeCategories.length ? "اختر تصنيفًا من تصنيفات المتجر" : "لا توجد تصنيفات محددة للمتجر"}
              disabled={storeCategories.length === 0}
            />
          ) : (
            <CategorySelect
              value={categoryId}
              onChange={handleCategoryChange}
              onMainChange={(main) => setSelectedMainCategoryName(main?.name || "")}
              required={true}
            />
          )}
        </div>
        {validationErrors.categoryId && <p className="text-xs text-red-600 font-bold">{validationErrors.categoryId}</p>}
      </div>

      {(isStoreProduct || adType === "sell") && categoryAttributes.length > 0 && (
        <div className="order-11">
          <CategoryAttributeFields
            attributes={categoryAttributes}
            values={attributeValues}
            onChange={handleAttributeChange}
            title={isStoreProduct ? "مواصفات المنتج" : "معلومات إضافية (اختياري)"}
          />
        </div>
      )}
      
      {/* Condition - Only show for enabled categories */}
      {!isStoreProduct && isConditionEnabled(selectedMainCategoryName) && (
        <div className="order-6 space-y-1">
          <label className="block text-sm font-medium text-gray-700">حالة المنتج</label>
          <div className="flex gap-2">
            {[
              { value: "new", label: "جديد" },
              { value: "used", label: "مستعمل" }
            ].map((opt) => (
              <button
                key={opt.value}
                type="button"
                onClick={() => setCondition(opt.value)}
                className={`flex-1 rounded-lg border px-3 py-2 text-sm transition-colors ${
                  condition === opt.value
                    ? "border-brand-500 bg-brand-50 text-brand-700"
                    : "border-gray-200 hover:bg-gray-50"
                }`}
              >
                {opt.label}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Tags - Only for sell type */}
      {!isStoreProduct && adType === "sell" && availableTags.length > 0 && (
        <div className="hidden">
          <label className="block text-sm font-medium text-gray-700">وسوم (اختياري)</label>
          <div className="flex flex-wrap gap-2">
            {availableTags.map((tag) => (
              <button
                key={tag._id}
                type="button"
                onClick={() => {
                  setSelectedTags((prev) =>
                    prev.includes(tag._id)
                      ? prev.filter((id) => id !== tag._id)
                      : [...prev, tag._id]
                  );
                }}
                className={`rounded-full px-3 py-1 text-xs transition-colors ${
                  selectedTags.includes(tag._id)
                    ? "bg-indigo-600 text-white"
                    : "bg-gray-100 text-gray-700 hover:bg-gray-200"
                }`}
              >
                {tag.name}
              </button>
            ))}
          </div>
        </div>
      )}
      
      {/* Contact Info - Same for both types */}
      {!isStoreProduct && <div className="order-10 space-y-3 rounded-lg border border-gray-200 p-4 bg-white">
        <h4 className="text-sm font-bold text-gray-700 mb-2">معلومات التواصل السريع</h4>
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="showPhone"
            className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
            checked={showPhone}
            onChange={(e) => setShowPhone(e.target.checked)}
          />
          <label htmlFor="showPhone" className="text-sm font-medium text-gray-700 cursor-pointer">عرض رقم الهاتف</label>
        </div>
        {showPhone && (
          <input
            className="ds-input"
            placeholder="رقم الهاتف (مثال: 777123456)"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
          />
        )}
        
        <div className="flex items-center gap-2">
          <input
            type="checkbox"
            id="showWhatsApp"
            className="w-4 h-4 rounded border-gray-300 text-green-600 focus:ring-green-500"
            checked={showWhatsApp}
            onChange={(e) => setShowWhatsApp(e.target.checked)}
          />
          <label htmlFor="showWhatsApp" className="text-sm font-medium text-gray-700 cursor-pointer">عرض واتساب</label>
        </div>
        {showWhatsApp && (
          <input
            className="ds-input"
            placeholder="رقم واتساب (مثال: 967777123456)"
            value={whatsapp}
            onChange={(e) => setWhatsApp(e.target.value)}
          />
        )}
      </div>}
      
      <div className="order-5 space-y-1">
        <label className="block text-sm font-medium text-gray-700">
          {t("addProduct.labels.description")}
        </label>
        <textarea
          className="ds-input"
          rows="4"
          placeholder={t("addProduct.labels.descriptionPh")}
          value={description}
          onChange={(e) => setDescription(e.target.value.slice(0, 1000))}
          maxLength={1000}
        />
        <div className="text-left text-xs font-bold text-gray-400" dir="ltr">{description.length}/1000</div>
      </div>

      {!isStoreProduct && <div className="order-9 grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div ref={formRefs.governorateId} className="space-y-1">
          <label className="block text-sm font-bold text-gray-700">
            المحافظة <span className="text-red-500 mr-1">*</span>
          </label>
          <div className={validationErrors.governorateId ? "rounded-xl border-2 border-red-500 bg-red-50/30" : ""}>
            <MobileSelect
              value={governorateId}
              onChange={(e) => {
                setGovernorateId(e.target.value);
                if (e.target.value) setValidationErrors(prev => ({ ...prev, governorateId: null }));
              }}
              required={true}
              options={governorates.map(g => ({ value: g._id, label: g.name }))}
              placeholder="اختر المحافظة..."
            />
          </div>
          {validationErrors.governorateId && <p className="text-xs text-red-600 font-bold">{validationErrors.governorateId}</p>}
        </div>
        <div ref={formRefs.cityId} className="space-y-1">
          <label className="block text-sm font-bold text-gray-700">
            المدينة <span className="text-red-500 mr-1">*</span>
          </label>
          <div className={validationErrors.cityId ? "rounded-xl border-2 border-red-500 bg-red-50/30" : ""}>
            <MobileSelect
              value={cityId}
              onChange={(e) => {
                setCityId(e.target.value);
                if (e.target.value) setValidationErrors(prev => ({ ...prev, cityId: null }));
              }}
              disabled={!governorateId}
              required={true}
              options={cities.map(c => ({ value: c._id, label: c.name }))}
              placeholder={governorateId ? "اختر المدينة..." : "اختر المحافظة أولاً"}
            />
          </div>
          {validationErrors.cityId && <p className="text-xs text-red-600 font-bold">{validationErrors.cityId}</p>}
        </div>
      </div>}

      <div ref={formRefs.price} className="order-7 grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="space-y-1 col-span-1 sm:col-span-2">
          <label className="block text-sm font-bold text-gray-700">
            {adType === "order" ? "السعر التقريبي" : t("addProduct.labels.price")} {adType !== "order" && <span className="text-red-500 mr-1">*</span>}
          </label>
          <input
            className={`ds-input disabled:bg-gray-100 disabled:cursor-not-allowed ${validationErrors.price ? "border-red-500 ring-2 ring-red-100" : ""}`}
            placeholder="0"
            type="text"
            inputMode="numeric"
            value={price}
            onChange={(e) => {
              setPrice(e.target.value.replace(/\D/g, ""));
              if (e.target.value) setValidationErrors(prev => ({ ...prev, price: null }));
            }}
            disabled={priceOnContact}
          />
          {validationErrors.price && <p className="text-xs text-red-600 font-bold">{validationErrors.price}</p>}
          
          {adType === "sell" && (
            <div className="mt-2 flex items-center gap-4">
              <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={negotiable}
                  onChange={(e) => setNegotiable(e.target.checked)}
                />
                قابل للتفاوض
              </label>
              {!isStoreProduct && <label className="flex items-center gap-2 text-sm text-gray-700">
                <input
                  type="checkbox"
                  checked={priceOnContact}
                  onChange={(e) => {
                    const v = e.target.checked;
                    setPriceOnContact(v);
                    if (v) {
                      setPrice("");
                      setValidationErrors(prev => ({ ...prev, price: null }));
                    }
                  }}
                />
                السعر عند التواصل
              </label>}
            </div>
          )}

        </div>
        <div className="space-y-1">
          <MobileSelect
            label={t("addProduct.labels.currency")}
            value={currency}
            onChange={(e) => setCurrency(e.target.value)}
            disabled={priceOnContact}
            required={true}
            options={[
              { value: "YER_ADEN", label: "ريال يمني (عدن)" },
              { value: "YER_SANAA", label: "ريال يمني (صنعاء)" },
              { value: "SAR", label: "ريال سعودي" },
              { value: "USD", label: "دولار" }
            ]}
          />
        </div>
      </div>
      {!priceOnContact && Number(price) > 0 && (
        <CurrencyCalculator amount={price} currency={currency} />
      )}

      {isStoreProduct && (
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700">حالة المنتج <span className="text-red-500 mr-1">*</span></label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { value: true, label: "متوفر" },
              { value: false, label: "غير متوفر" }
            ].map((option) => (
              <button
                key={String(option.value)}
                type="button"
                aria-pressed={isAvailable === option.value}
                onClick={() => setIsAvailable(option.value)}
                className={`min-h-12 rounded-xl border px-4 py-3 text-sm font-bold transition-colors ${isAvailable === option.value ? "border-emerald-600 bg-emerald-50 text-emerald-800" : "border-slate-200 bg-white text-slate-600 hover:bg-slate-50"}`}
              >
                {option.label}
              </button>
            ))}
          </div>
        </div>
      )}
      {isStoreProduct && supportsDelivery && (
        <label className="flex items-center gap-3 rounded-xl border border-amber-200 bg-amber-50 p-4 text-sm font-bold text-amber-950">
          <input
            type="checkbox"
            checked={isAvailableForDelivery}
            onChange={(event) => setIsAvailableForDelivery(event.target.checked)}
            className="h-5 w-5 accent-amber-500"
          />
          متاح للتوصيل
        </label>
      )}
      {isStoreProduct && supportsInventory && (
        <section className="space-y-3 rounded-xl border border-violet-200 bg-violet-50 p-4">
          <label className="flex items-center gap-3 text-sm font-bold text-violet-950">
            <input
              type="checkbox"
              checked={inventoryEnabled}
              onChange={(event) => setInventoryEnabled(event.target.checked)}
              className="h-5 w-5 accent-violet-600"
            />
            تفعيل المخزون
          </label>
          {inventoryEnabled && (
            <label className="block text-sm font-bold text-slate-700">
              الكمية المتوفرة
              <input
                type="number"
                min="0"
                step="1"
                value={stockQuantity}
                onChange={(event) => setStockQuantity(event.target.value)}
                required
                className="mt-2 w-full rounded-xl border border-violet-200 bg-white px-4 py-3"
              />
            </label>
          )}
        </section>
      )}
      {isStoreProduct && supportsDiscounts && (
        <section className="space-y-3 rounded-xl border border-rose-200 bg-rose-50 p-4">
          <label className="flex items-center gap-3 text-sm font-bold text-rose-950">
            <input
              type="checkbox"
              checked={discountEnabled}
              onChange={(event) => setDiscountEnabled(event.target.checked)}
              className="h-5 w-5 accent-rose-600"
            />
            خصم على المنتج
          </label>
          {discountEnabled && (
            <>
              <label className="block text-sm font-bold text-slate-700">
                نوع الخصم
                <select
                  value={discountType}
                  onChange={(event) => setDiscountType(event.target.value)}
                  className="mt-2 w-full rounded-xl border border-rose-200 bg-white px-4 py-3"
                >
                  <option value="percentage">نسبة مئوية</option>
                  <option value="fixed">مبلغ ثابت</option>
                </select>
              </label>
              <label className="block text-sm font-bold text-slate-700">
                {discountType === "percentage" ? "نسبة الخصم %" : `مبلغ الخصم (${currency})`}
                <input
                  type="number"
                  min="1"
                  max={discountType === "percentage" ? 99 : Number(price)}
                  step={discountType === "percentage" ? "1" : "any"}
                  value={discountValue}
                  onChange={(event) => setDiscountValue(event.target.value)}
                  required
                  className="mt-2 w-full rounded-xl border border-rose-200 bg-white px-4 py-3"
                />
              </label>
            </>
          )}
        </section>
      )}

      {AD_COMMISSION_ENABLED && !isStoreProduct && adType === "sell" && !priceOnContact && Number(price) > 0 && (
        <div className="order-8 mt-2 rounded-md border border-blue-200 bg-blue-50 px-2 py-1.5 text-center text-xs text-blue-900 sm:px-3 sm:py-2 sm:text-sm">
          <div className="font-semibold">عمولة المنصة على هذا الإعلان</div>
          <div className="text-[10px] sm:text-xs">نسبة العمولة: 1%</div>
          <div className="mt-1 text-[10px] sm:text-xs">العمولة المتوقعة:</div>
          <div className="mt-0.5 text-lg font-bold sm:text-xl">
            {Math.round(Number(price) * 0.01)}{" "}
            {currency === "USD" ? "$" : currency === "SAR" ? "ر.س" : currency === "YER_SANAA" ? "ر.ي (صنعاء)" : "ر.ي (عدن)"}
          </div>
          {(currency === "YER_ADEN" || currency === "YER_SANAA" || currency === "YER") && Math.round(Number(price) * 0.01) < 1000 && (
            <div className="mt-1 text-center text-[10px] text-amber-700 font-bold sm:text-xs">
              إذا كانت العمولة أقل من 1000 ريال يمني (عدن) فيُستحب التصدق بها.
            </div>
          )}
        </div>
      )}
      
      <div ref={formRefs.files} className="order-4 space-y-1">
        <label className="block text-sm font-bold text-gray-700">
          {isStoreProduct ? "صور المنتج" : t("addProduct.labels.images")} {adType !== "order" && !isStoreProduct && <span className="text-red-500 mr-1">*</span>}
        </label>
        <div className={`relative ${validationErrors.files ? "rounded-xl border-2 border-red-500 bg-red-50/30 p-1" : ""}`}>
          <input id="ad-images-input" className="sr-only" type="file" multiple accept="image/png,image/jpeg,image/jpg" onChange={handleFiles} />
          <label htmlFor="ad-images-input" className="flex min-h-14 w-full cursor-pointer items-center justify-center rounded-xl border border-dashed border-blue-300 bg-blue-50/60 px-4 py-3 text-sm font-black text-blue-700 transition hover:border-blue-500 hover:bg-blue-50">
            {isStoreProduct ? "إضافة صور المنتج" : "إضافة صور الإعلان"}
          </label>
        </div>
        {validationErrors.files && <p className="text-xs text-red-600 font-bold">{validationErrors.files}</p>}
        <p className="text-xs text-gray-500">
          {adType === "order" ? "يمكنك رفع صور توضيحية للمنتج الذي تطلبه (اختياري)." : isStoreProduct ? "يمكنك إضافة حتى 10 صور للمنتج." : "يفضل رفع صورة واحدة على الأقل، وحد أقصى 10 صور."}
        </p>
      </div>
      {previews.length > 0 && (
        <div className="order-4 mt-2 flex flex-wrap gap-3">
          {previews.map((src, i) => (
            <div key={src} className="relative">
              <img src={src} alt={`${isStoreProduct ? "صورة المنتج" : "صورة الإعلان"} ${i + 1}`} className="h-24 w-32 rounded-md object-cover" />
              <button
                type="button"
                aria-label={`حذف ${isStoreProduct ? "صورة المنتج" : "صورة الإعلان"} ${i + 1}`}
                onClick={() => removeFile(i)}
                className="absolute -right-2 -top-2 flex h-7 w-7 items-center justify-center rounded-full bg-red-600 text-lg font-bold leading-none text-white shadow-md transition-colors hover:bg-red-700"
              >
                ×
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Brokerage System */}
      {!isStoreProduct && adType === "sell" && brokerageEnabled && (
        <div className="order-12 space-y-4 rounded-xl border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2">
            <input
              type="checkbox"
              id="enableBrokerage"
              className="h-5 w-5 rounded border-gray-300 text-amber-600 focus:ring-amber-500"
              checked={enableBrokerage}
              onChange={(e) => setEnableBrokerage(e.target.checked)}
            />
            <label htmlFor="enableBrokerage" className="text-sm font-black text-amber-900 cursor-pointer">
              تفعيل نظام التسويق بالعمولة
            </label>
          </div>

          {enableBrokerage && (
            <div className="space-y-4 pt-2 animate-in fade-in slide-in-from-top-2">
              <div className="space-y-2">
                <label className="block text-sm font-bold text-gray-700">
                  نوع الحملة
                </label>
                <MobileSelect
                  value={brokerageType}
                  onChange={(e) => setBrokerageType(e.target.value)}
                  options={[
                    { value: "AUTO_JOIN", label: "انضمام تلقائي" },
                    { value: "MANUAL_APPROVAL", label: "موافقة يدوية" },
                    { value: "LIMITED", label: "عدد محدود" }
                  ]}
                />
              </div>

              {brokerageType === "LIMITED" && (
                <div className="space-y-1">
                  <label className="block text-sm font-bold text-gray-700">
                  الحد الأقصى للوسطاء
                </label>
                  <input
                    className="ds-input"
                    type="number"
                    min="1"
                    value={brokerageMaxBrokers}
                    onChange={(e) => setBrokerageMaxBrokers(e.target.value)}
                    placeholder="أدخل عدد الوسطاء"
                  />
                </div>
              )}

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <label className="block text-sm font-bold text-gray-700">
                  نوع المكافأة
                  </label>
                  <MobileSelect
                    value={brokerageRewardType}
                    onChange={(e) => setBrokerageRewardType(e.target.value)}
                    options={[
                      { value: "FIXED", label: "مبلغ ثابت" },
                      { value: "PERCENTAGE", label: "نسبة مئوية" }
                    ]}
                  />
                </div>
                <div className="space-y-1">
                  <label className="block text-sm font-bold text-gray-700">
                    {brokerageRewardType === "PERCENTAGE" ? "النسبة %" : "المبلغ"}
                  </label>
                  <input
                    className="ds-input"
                    type="number"
                    min={brokerageRewardType === "PERCENTAGE" ? "1" : "100"}
                    max={brokerageRewardType === "PERCENTAGE" ? "30" : undefined}
                    value={brokerageRewardValue}
                    onChange={(e) => setBrokerageRewardValue(e.target.value)}
                    placeholder={brokerageRewardType === "PERCENTAGE" ? "1-30%" : "أقل مبلغ 100"}
                  />
                </div>
              </div>

              {brokerageRewardType === "PERCENTAGE" && (
                <div className="mt-2 rounded-md border border-amber-200 bg-amber-100 px-3 py-2 text-center text-sm text-amber-800">
                  المكافأة المتوقعة: {Math.round(Number(price) * (Number(brokerageRewardValue) / 100))} {currency === "USD" ? "$" : currency === "SAR" ? "ر.س" : currency === "YER_SANAA" ? "ر.ي (صنعاء)" : "ر.ي (عدن)"}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {(prepareStatus || isPreparingImages || loading) && (
        <div className="order-12 rounded-2xl border border-blue-200 bg-blue-50 px-4 py-3 text-sm font-bold text-blue-900">
          {prepareStatus || (loading ? (isStoreProduct ? "جارٍ حفظ المنتج..." : "جارٍ النشر...") : "جارٍ تجهيز الصور...")}
        </div>
      )}

      {/* Submit Button */}
      <button 
        type="submit"
        className="order-[13] w-full h-16 rounded-[2rem] bg-gray-900 text-white font-black text-lg hover:bg-black disabled:opacity-50 transition-all shadow-2xl active:scale-[0.98]" 
        disabled={loading || isPreparingImages || !!blockErr} 
      >
        {isPreparingImages ? "جارٍ تجهيز الصور..." : loading ? (isStoreProduct ? "جارٍ حفظ المنتج..." : "جارٍ النشر...") : isStoreProduct ? "إضافة المنتج" : "نشر الإعلان الآن"}
      </button>
      {showAfterPublishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl border bg-white p-8 shadow-2xl animate-in zoom-in duration-300">
            <div className="mb-4 flex justify-center">
              <div className="rounded-full bg-green-100 p-3">
                <svg className="h-8 w-8 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                </svg>
              </div>
            </div>
            <p className="text-center font-bold text-gray-900 text-lg mb-2">
              {isStoreProduct ? "تمت إضافة المنتج بنجاح!" : adType === "order" ? "تم نشر طلب الشراء بنجاح!" : "تم نشر الإعلان بنجاح!"}
            </p>
            <p className="text-center text-sm text-gray-500 mb-8">
              {isStoreProduct ? "سيظهر المنتج في متجرك بعد مراجعته." : adType === "order"
                ? "سيتم مراجعة طلبك من قبل الإدارة وسيظهر للجميع فور الموافقة عليه."
                : "سيتم مراجعة إعلانك من قبل الإدارة في أقرب وقت."}
            </p>
            <div className="flex flex-col gap-3">
              {!isStoreProduct && <Link
                to="/seller/subscriptions"
                className="group relative overflow-hidden rounded-xl bg-gradient-to-r from-amber-500 to-orange-600 px-5 py-3.5 text-center text-sm font-black text-white hover:shadow-xl hover:shadow-orange-200 transition-all active:scale-95"
              >
                <div className="flex items-center justify-center gap-2">
                  <span className="text-lg">🌟</span>
                  <span>بيع أسرع! ميز إعلانك الآن</span>
                </div>
                <div className="absolute inset-0 bg-white/20 -translate-x-full group-hover:translate-x-full transition-transform duration-1000 skew-x-12"></div>
              </Link>}
              <button
                type="button"
                onClick={() => {
                  setShowAfterPublishModal(false);
                  navigate(isStoreProduct ? storeDashboardPath : "/my-ads");
                }}
                className="rounded-xl border-2 border-gray-100 bg-gray-50/50 px-5 py-3 text-sm font-bold text-gray-700 hover:bg-white hover:border-gray-200 transition-all"
              >
                {isStoreProduct ? "العودة إلى منتجات المتجر" : "عرض إعلاناتي"}
              </button>
            </div>
          </div>
        </div>
      )}
    </form>
    </div>
  );
}
