import React, { useEffect, useState, useCallback } from "react";
import { useNavigate, Link, useSearchParams } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { useAuth } from "../store/AuthContext.jsx";
import { useApi } from "../api/axios.js";
import { useAdsQuery } from "../hooks/useAdsQuery.js";
import { useGovernorates } from "../hooks/useGovernorates.js";
import ProductCard from "../components/ProductCard.jsx";
import SponsoredAdSlot from "../components/SponsoredAdSlot.jsx";
import CategoryGrid from "../components/CategoryGrid.jsx";
import AdvancedSearchModal from "../components/AdvancedSearchModal.jsx";
import MobileSelect from "../components/MobileSelect.jsx";
import SEO from "../components/SEO.jsx";
import { useSsgData } from "../ssg/SsgDataContext.jsx";
import IncompleteActions from "../components/IncompleteActions.jsx";
import ServiceFeatureCarousel from "../components/ServiceFeatureCarousel.jsx";
import ExpiringAuctions from "../components/ExpiringAuctions.jsx";

const EMPTY_GOVERNORATES = [];

const HOME_SERVICES = [
  { label: "متاجر", to: "/stores", icon: "store", color: "text-blue-600", background: "bg-blue-50 dark:bg-blue-900/20" },
  { label: "أسر منتجة", to: "/family-production", icon: "family", color: "text-fuchsia-600", background: "bg-fuchsia-50 dark:bg-fuchsia-900/20" },
  { label: "خدمات الدفع الإلكتروني", to: "/wallet-services", icon: "payment", color: "text-cyan-600", background: "bg-cyan-50 dark:bg-cyan-900/20" },
  { label: "تسعيرة", to: "/quote-requests", icon: "quote", color: "text-violet-600", background: "bg-violet-50 dark:bg-violet-900/20" },
  { label: "مزادات", to: "/auctions", icon: "auction", color: "text-amber-600", background: "bg-amber-50 dark:bg-amber-900/20" },
  { label: "حجوزات", to: "/bookings", icon: "booking", color: "text-emerald-600", background: "bg-emerald-50 dark:bg-emerald-900/20" }
];

function HomeServiceIcon({ name }) {
  const iconPaths = {
    store: <><path d="M3 10h18l-1.5-6h-15L3 10Z" /><path d="M5 10v10h14V10M9 20v-6h6v6M3 10a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0" /></>,
    family: <><path d="m3 10 9-7 9 7v10H3V10Z" /><path d="M9 20v-6h6v6M12 11s-3-1.5-3-3.5A1.8 1.8 0 0 1 12 6a1.8 1.8 0 0 1 3 1.5C15 9.5 12 11 12 11Z" /></>,
    payment: <><rect x="3" y="5" width="18" height="14" rx="2" /><path d="M3 10h18M7 15h4" /></>,
    quote: <><path d="M20.5 13.5 13 21l-10-10V3h8l9.5 9.5a.7.7 0 0 1 0 1Z" /><circle cx="7.5" cy="7.5" r="1" /><path d="M12 8h4M12 11h5" /></>,
    auction: <><path d="m14 5 5 5M4 20l8-8M8 4l5 5-4 4-5-5 4-4ZM16 12l4 4-4 4-4-4 4-4Z" /><path d="M3 21h18" /></>,
    booking: <><rect x="3" y="5" width="18" height="16" rx="2" /><path d="M7 3v4m10-4v4M3 10h18m-12 4h.01M12 14h.01M15 14h.01M9 17h.01M12 17h.01" /></>
  };

  return (
    <svg aria-hidden="true" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" className="h-6 w-6 sm:h-7 sm:w-7">
      {iconPaths[name]}
    </svg>
  );
}

export default function Home() {
  const { user } = useAuth();
  const ssgData = useSsgData();
  const initialHome = ssgData?.kind === "home" ? ssgData.data : null;
  const api = useApi();
  const { prefetchCategoryAds, prefetchNextPage } = useAdsQuery();
  const { data: governoratesData = EMPTY_GOVERNORATES } = useGovernorates();
  const [searchParams, setSearchParams] = useSearchParams();
  const navigate = useNavigate();

  // Filters from URL
  const q = searchParams.get("q") || "";
  const governorateId = searchParams.get("governorateId") || "";
  const minPrice = searchParams.get("minPrice") || "";
  const maxPrice = searchParams.get("maxPrice") || "";
  const page = parseInt(searchParams.get("page") || "1");
  const sort = searchParams.get("sort") || "new";

  const [products, setProducts] = useState(initialHome?.ads || []);
  const [governorates, setGovernorates] = useState([]);
  const [cities, setCities] = useState([]);
  const [popularTags, setPopularTags] = useState([]);
  const [loading, setLoading] = useState(false);
  const [pages, setPages] = useState(() => {
    if (Number.isFinite(initialHome?.pages)) return initialHome.pages;
    return 1;
  });
  const [showAdvancedModal, setShowAdvancedModal] = useState(false);
  const [recentlyViewed, setRecentlyViewed] = useState([]);
  const [platformStats, setPlatformStats] = useState({ avgRating: 0, totalCount: 0 });

  useEffect(() => {
    // Load recently viewed from localStorage
    const recent = JSON.parse(localStorage.getItem("recentlyViewed") || "[]");
    
    // Filter out ads that don't belong to the current user (if logged in)
    // We store userId in the recentlyViewed items for this purpose
    if (user) {
      const userKey = user._id || user.id;
      const userSpecificRecent = recent.filter(item => item.viewerId === userKey);
      setRecentlyViewed(userSpecificRecent);
    } else {
      // For guest, show only items viewed as guest
      const guestRecent = recent.filter(item => !item.viewerId || item.viewerId === "guest");
      setRecentlyViewed(guestRecent);
    }

    // Fetch platform stats
    (async () => {
      try {
        const res = await api.get("/platform-reviews/stats");
        setPlatformStats(res.data);
      } catch (err) {
        console.error("Error fetching platform stats:", err);
      }
    })();
  }, [user]);

  const updateFilters = useCallback((updates) => {
    setSearchParams(prev => {
      const next = new URLSearchParams(prev);
      Object.entries(updates).forEach(([key, value]) => {
        if (value) next.set(key, value);
        else next.delete(key);
      });
      // Reset page when filters change unless page itself is being updated
      if (!updates.page) next.set("page", "1");
      return next;
    }, { replace: true, preventScrollReset: true });
  }, [setSearchParams]);

  const handleSearchSubmit = (overrideQuery = null) => {
    const finalQuery = (typeof overrideQuery === "string" ? overrideQuery : q) || "";
    setShowQuickSearch(false);
    const params = new URLSearchParams(searchParams);
    if (finalQuery.trim()) params.set("q", finalQuery.trim());
    else params.delete("q");
    navigate(`/search?${params.toString()}`);
  };

  const load = useCallback(async () => {
    if (loading) return;
    setLoading(true);
    try {
      const currentLimit = 20;
      const isInitialRestore = page > 1 && products.length === 0;
      
      const params = {
        q: q || undefined,
        governorateId: governorateId || undefined,
        minPrice: minPrice || undefined,
        maxPrice: maxPrice || undefined,
        page: isInitialRestore ? 1 : page,
        limit: isInitialRestore ? page * currentLimit : currentLimit,
        sort
      };

      const res = await api.get("/ads", { params });
      const data = res.data && res.data.items ? res.data : { items: res.data, page: 1, pages: 1 };
      
      if (page === 1 || isInitialRestore) {
        setProducts(data.items || []);
      } else {
        setProducts((prev) => [...prev, ...(data.items || [])]);
      }
      
      const total = data.total || (data.items?.length || 0);
      const totalPages = Math.ceil(total / currentLimit) || 1;
      setPages(totalPages);

      if (page < totalPages) {
        prefetchNextPage(params, page, totalPages);
      }
    } catch (err) {
      console.error("Error loading ads:", err);
      if (!initialHome?.ads?.length) {
        setProducts([]);
        setPages(1);
      }
    } finally {
      setLoading(false);
    }
  }, [q, governorateId, minPrice, maxPrice, page, sort]);

  useEffect(() => {
    load();
  }, [load, initialHome, q, governorateId, minPrice, maxPrice, page, sort]);

  useEffect(() => {
    setGovernorates(governoratesData);
  }, [governoratesData]);

  useEffect(() => {
    if (!governorateId) {
      setCities([]);
      return;
    }
    (async () => {
      try {
        const res = await api.get("/cities", { params: { governorateId, active: true } });
        setCities(res.data || []);
      } catch {
        setCities([]);
      }
    })();
  }, [governorateId]);

  useEffect(() => {
    (async () => {
      try {
        const res = await api.get("/tags", { params: { popular: true } });
        setPopularTags(res.data || []);
      } catch {
        setPopularTags([]);
      }
    })();
  }, []);

  return (
    <>
      <SEO
        title="سوقك - سوق اليمن للإعلانات والبيع والشراء"
        description="سوقك هو منصة يمنية موثوقة للبيع والشراء والإعلانات المبوبة مع ميزة الشراء الآمن، وتتيح لك عرض وشراء السيارات، العقارات، الإلكترونيات والمنتجات والخدمات بسهولة."
        canonicalUrl="/"
        includeSearchAction
      />
      <div className="-mx-4 min-h-screen bg-[#f7faff] dark:bg-slate-950 dark:text-slate-100 font-sans leading-relaxed sm:mx-0 sm:bg-slate-50">
      {/* Hero Section */}
      <section className="hidden sm:block relative -translate-y-2 sm:-translate-y-3 overflow-hidden rounded-b-[40px] sm:rounded-b-[60px] border-b border-blue-100/60 shadow-2xl shadow-blue-200/50 dark:border-slate-800 dark:shadow-slate-900/40">
        {/* Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-700 via-blue-800 to-indigo-900">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.03%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-30"></div>
          <div className="absolute -top-28 -right-20 h-96 w-96 rounded-full bg-blue-400/20 blur-[100px] animate-float"></div>
          <div className="absolute -bottom-24 -left-10 h-80 w-80 rounded-full bg-indigo-400/20 blur-[80px] animate-float-slow"></div>
          
          {/* Hero Floating Stats - Removed as requested */}
        </div>
        
        {/* Content */}
        <div className="relative container mx-auto px-4 py-4 sm:py-8 md:py-10 lg:py-12">
          <div className="text-center max-w-4xl mx-auto animate-in fade-in slide-in-from-bottom-8 duration-1000">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-white/90 text-[10px] sm:text-xs mb-3 sm:mb-4 border border-white/20 shadow-xl">
              <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(96,165,250,0.8)]"></span>
              أكبر تجمع تجاري في اليمن
            </div>
            
            <h2 className="text-2xl sm:text-4xl md:text-5xl lg:text-6xl font-black text-white mb-2 sm:mb-3 leading-[1.35] sm:leading-[1.35] md:leading-[1.35] lg:leading-[1.35] tracking-tight">
              بيع واشترِ <br className="hidden sm:block" />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-200 to-indigo-100">بكل سهولة وأمان</span>
            </h2>

            <p className="text-[11px] sm:text-lg text-white/70 mb-3 sm:mb-5 px-4 max-w-2xl mx-auto font-medium leading-relaxed">
              سوقك الموثوق لكل ما تحتاجه في اليمن
            </p>
            
            {/* Removed Hero Stats Mobile Version */}
            
            {/* Search Bar - Optimized for Mobile */}
            <div className="w-full mx-auto px-1 sm:px-0">
              <div className="flex items-center gap-1 p-1 rounded-2xl sm:rounded-[24px] bg-white shadow-2xl shadow-black/20 focus-within:ring-4 focus-within:ring-blue-500/20 transition-all duration-300">
                <div className="flex-1 flex items-center gap-2 px-2 sm:px-4">
                  <svg className="w-4 h-4 sm:w-6 sm:h-6 text-blue-600 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  <input
                    type="text"
                    placeholder="ما الذي تبحث عنه؟"
                    value={q}
                    onChange={(e) => updateFilters({ q: e.target.value })}
                    onKeyDown={(e) => e.key === "Enter" && handleSearchSubmit()}
                    className="flex-1 py-2 sm:py-4 text-slate-900 placeholder-slate-400 bg-transparent text-[13px] sm:text-lg font-bold outline-none"
                  />
                </div>
                <button
                  onClick={() => handleSearchSubmit()}
                  className="px-4 sm:px-10 py-2 sm:py-4 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-xl sm:rounded-[20px] font-black transition-all hover:shadow-lg hover:scale-[1.02] active:scale-95 text-[12px] sm:text-lg whitespace-nowrap shadow-blue-500/25"
                >
                  ابحث
                </button>
              </div>
            </div>

            {/* Hero Actions */}
            <div className="mt-4 sm:mt-6 flex flex-wrap items-center justify-center gap-3">
              <Link
                to="/choose-add-type"
                className="group relative flex items-center gap-2 rounded-xl sm:rounded-2xl bg-white px-6 sm:px-8 py-2.5 sm:py-3.5 text-[13px] sm:text-base font-black text-blue-700 shadow-xl shadow-black/10 transition-all hover:scale-105 active:scale-95 hover:bg-blue-50 overflow-hidden"
              >
                <span className="relative z-10">أضف إعلانك مجاناً</span>
                <svg className="w-4 h-4 sm:w-5 sm:h-5 relative z-10 transition-transform group-hover:translate-x-[-4px]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                </svg>
              </Link>
            </div>
          </div>
        </div>
      </section>

      <div className="container mx-auto px-4 pb-2 pt-2 sm:pb-6 sm:pt-5">
        <ServiceFeatureCarousel />
      </div>

      {/* Main Content */}
      <main className="container mx-auto px-4 mt-0 sm:-mt-12 relative z-10">
        {user && <div className="mb-5 sm:mb-8"><IncompleteActions userId={user._id || user.id} compact /></div>}
        <ExpiringAuctions />
        <Link
          to="/platform-reviews"
          className="group -mt-4 mb-5 flex items-center justify-between gap-3 rounded-2xl border border-blue-100 bg-white px-4 py-3 shadow-lg shadow-blue-100/50 transition-all hover:-translate-y-0.5 hover:border-blue-300 sm:mt-0 sm:mb-8 sm:px-6 sm:py-4 dark:border-slate-800 dark:bg-slate-900 dark:shadow-none"
        >
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex items-center gap-0.5 text-amber-400" aria-label="تقييم المنصة">
              {[...Array(5)].map((_, i) => (
                <svg key={i} className={`h-4 w-4 sm:h-5 sm:w-5 ${i < Math.floor(platformStats.avgRating || 0) ? "fill-current" : "fill-slate-200 dark:fill-slate-700"}`} viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              ))}
            </div>
            <div className="min-w-0">
              <p className="whitespace-nowrap text-sm font-black text-slate-900 dark:text-white sm:text-base">تقييم منصة سوقك</p>
              <p className="hidden text-[10px] font-bold text-slate-500 dark:text-slate-400 sm:block sm:text-xs">شاركنا رأيك وساعدنا على التطور</p>
            </div>
          </div>
          <div className="flex shrink-0 items-center gap-2">
            <span className="text-lg font-black text-blue-600 sm:text-xl">{platformStats.avgRating ? platformStats.avgRating.toFixed(1) : "0.0"}</span>
            <svg className="h-4 w-4 text-blue-500 transition-transform group-hover:-translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </div>
        </Link>

        <Link
          to="/partners"
          className="mb-6 flex min-w-0 items-center justify-between gap-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-sm transition hover:border-blue-200 hover:shadow-md dark:border-slate-800 dark:bg-slate-900 sm:mb-8 sm:p-5"
        >
          <div className="flex min-w-0 items-center gap-3 sm:gap-5">
            <div className="flex shrink-0 items-center gap-2 rounded-xl bg-slate-50 p-2 dark:bg-slate-800 sm:gap-3 sm:p-3">
              <img src="/Amana-Logo.svg" alt="" loading="lazy" decoding="async" className="h-7 w-7 object-contain sm:h-9 sm:w-9" />
              <span className="h-7 w-px bg-slate-200 dark:bg-slate-700" />
              <img src="/tmam-full-logo.png" alt="" loading="lazy" decoding="async" className="h-7 w-12 object-contain sm:h-9 sm:w-16" />
            </div>
            <div className="min-w-0">
              <h2 className="text-sm font-black text-slate-900 dark:text-white sm:text-base">تعرّف على شركائنا</h2>
              <p className="mt-1 text-[11px] font-semibold leading-4 text-slate-500 dark:text-slate-400 sm:text-sm sm:leading-5">أمانة للوساطة، وتمام باي لخدمات الدفع الإلكتروني</p>
            </div>
          </div>
          <span aria-hidden="true" className="shrink-0 text-lg font-black text-blue-600">←</span>
        </Link>

        {/* Trust Highlights - Optimized for Mobile */}
        <section className="hidden sm:grid mb-10 sm:mb-16 grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4 animate-in fade-in slide-in-from-bottom-12 duration-1000 delay-300 fill-mode-both">
          {[
            { title: "واجهة ذكية", desc: "تصفح سريع وسهل", icon: "⚡", color: "from-amber-400 to-orange-500" },
            { title: "حماية كاملة", desc: "بيع وشراء آمن", icon: "🛡️", color: "from-blue-500 to-indigo-600" },
            { title: "متوافق تماماً", desc: "لكافة الأجهزة", icon: "📱", color: "from-emerald-400 to-teal-500" },
            { title: "دقة عالية", desc: "نتائج ذكية", icon: "🎯", color: "from-purple-500 to-pink-600" }
          ].map((item) => (
            <div key={item.title} className="group p-3 sm:p-5 rounded-2xl sm:rounded-3xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-xl shadow-slate-200/50 dark:shadow-none transition-all duration-300 hover:scale-105">
              <div className={`mb-2 sm:mb-4 inline-flex h-8 w-8 sm:h-12 sm:w-12 items-center justify-center rounded-xl sm:rounded-2xl bg-gradient-to-br ${item.color} text-sm sm:text-xl text-white shadow-lg transition-transform group-hover:rotate-6`}>
                {item.icon}
              </div>
              <h4 className="text-[11px] sm:text-lg font-black text-slate-900 dark:text-white mb-0.5 sm:mb-1 leading-tight">{item.title}</h4>
              <p className="text-[9px] sm:text-sm text-slate-500 dark:text-slate-400 font-medium leading-tight">{item.desc}</p>
            </div>
          ))}
        </section>

        {/* Categories Section */}
        <section className="mb-1 py-2 sm:mb-16 sm:py-12 lg:hidden rounded-none sm:rounded-[40px] bg-transparent sm:bg-slate-100/50 dark:bg-transparent sm:dark:bg-slate-900/30 border-0 sm:border border-slate-200/50 dark:border-slate-800/50">
          <div className="px-1 sm:px-6 mb-2 sm:mb-8 flex items-center justify-between">
            <div>
              <h3 className="text-base sm:text-3xl font-black text-slate-900 dark:text-white mb-1">تصفح حسب الفئة</h3>
              <p className="hidden text-[10px] sm:block sm:text-base text-slate-500 dark:text-slate-400 font-bold">اكتشف جميع الأقسام المتاحة</p>
            </div>
            <Link to="/categories" className="text-[11px] sm:text-sm font-black text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 group">
              عرض الكل
              <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4 transition-transform group-hover:translate-x-[-4px]" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
              </svg>
            </Link>
          </div>
          <CategoryGrid isHome={true} />
        </section>

        <section aria-labelledby="home-services-heading" className="mb-8 sm:mb-14">
          <div className="mb-3 flex items-center justify-between px-1 sm:mb-5 sm:px-2">
            <div>
              <h3 id="home-services-heading" className="text-lg font-black text-slate-900 dark:text-white sm:text-2xl">خدمات سوقك</h3>
              <p className="mt-0.5 text-[11px] font-medium text-slate-500 dark:text-slate-400 sm:text-sm">اكتشف خدمات التسوق والتجارة في سوقك</p>
            </div>
            <Link to="/seller/subscriptions" className="flex items-center gap-1 text-[11px] font-black text-blue-600 hover:underline dark:text-blue-400 sm:text-sm">
              عرض الكل
              <svg className="h-3.5 w-3.5 transition-transform group-hover:translate-x-[-4px] sm:h-4 sm:w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
              </svg>
            </Link>
          </div>
          <div className="flex snap-x snap-mandatory gap-2 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden sm:grid sm:grid-cols-6 sm:gap-3 sm:overflow-visible sm:pb-0 sm:snap-none">
            {HOME_SERVICES.map((service) => {
              const content = (
                <>
                  <span className={`mb-1.5 flex h-11 w-11 items-center justify-center rounded-2xl ${service.background} ${service.color} sm:mb-2 sm:h-14 sm:w-14`}>
                    <HomeServiceIcon name={service.icon} />
                  </span>
                  <span className="text-center text-[11px] font-black leading-4 text-slate-800 dark:text-slate-100 sm:text-sm sm:leading-5">
                    {service.label}
                  </span>
                </>
              );

              return service.to ? (
                <Link
                  key={service.label}
                  to={service.to}
                  className="flex min-h-[88px] w-24 shrink-0 snap-start flex-col items-center justify-center rounded-2xl border border-slate-100 bg-white px-1.5 py-2 shadow-sm transition hover:-translate-y-0.5 hover:border-blue-200 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-500 dark:border-slate-800 dark:bg-slate-900 sm:min-h-[112px] sm:w-auto sm:shrink sm:snap-align-none sm:rounded-3xl sm:py-3"
                >
                  {content}
                </Link>
              ) : (
                <div
                  key={service.label}
                  aria-label={`${service.label} - قريبًا`}
                  className="flex min-h-[88px] w-24 shrink-0 snap-start flex-col items-center justify-center rounded-2xl border border-slate-100 bg-white px-1.5 py-2 dark:border-slate-800 dark:bg-slate-900 sm:min-h-[112px] sm:w-auto sm:shrink sm:snap-align-none sm:rounded-3xl sm:py-3"
                >
                  {content}
                </div>
              );
            })}
          </div>
        </section>

        {/* Recently Viewed Section */}
        {recentlyViewed.length > 0 && (
          <section className="mb-8 sm:mb-16">
            <div className="flex items-center justify-between mb-4 sm:mb-6 px-2">
              <div>
                <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">شوهد مؤخراً</h3>
                <p className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider">تابع تصفح ما أعجبك سابقاً</p>
              </div>
              <button 
                onClick={() => { localStorage.removeItem("recentlyViewed"); setRecentlyViewed([]); }}
                className="text-[10px] font-black text-red-500 hover:text-red-600 transition-colors"
              >
                مسح القائمة
              </button>
            </div>
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-4 -mx-4 px-4 sm:mx-0 sm:px-0">
              {recentlyViewed.map((product) => (
                <div key={product._id} className="w-[160px] sm:w-[220px] shrink-0">
                  <ProductCard
                    product={product}
                    to={`/ad/${product._id}`}
                    governorateName={product.governorateId?.name}
                  />
                </div>
              ))}
            </div>
          </section>
        )}

        <div className="lg:grid lg:grid-cols-[280px_minmax(0,1fr)] lg:items-start lg:gap-6">
        <aside className="sticky top-24 hidden self-start lg:block">
          <div className="rounded-2xl border border-slate-100 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900">
            <div className="mb-3 flex items-center justify-between gap-2">
              <h3 className="text-lg font-black text-slate-900 dark:text-white">الفئات الرئيسية</h3>
              <Link to="/categories" className="shrink-0 text-xs font-bold text-blue-600 hover:underline dark:text-blue-400">
                عرض الكل
              </Link>
            </div>
            <div className="max-h-[calc(100vh-11rem)] overflow-y-auto overscroll-contain pr-1">
              <CategoryGrid layout="sidebar" />
            </div>
          </div>
        </aside>
        <section className="mb-10 min-w-0 sm:mb-16">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4 mb-4 sm:mb-10 px-2">
            <div>
              <h3 className="text-2xl sm:text-3xl font-black text-slate-900 dark:text-white mb-1 sm:mb-2">أحدث الإعلانات</h3>
              <p className="text-sm sm:text-base text-slate-500 dark:text-slate-400 font-bold">إعلانات جديدة تضاف كل دقيقة</p>
            </div>
            
            <div className="hidden sm:flex items-center gap-2 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800 shadow-sm self-stretch sm:self-auto overflow-x-auto no-scrollbar">
              {[
                { label: "الأحدث", value: "new" },
                { label: "المميزة أولاً", value: "featured" },
                { label: "الأرخص", value: "price_asc" },
                { label: "الأغلى", value: "price_desc" }
              ].map((s) => (
                <button
                  key={s.value}
                  onClick={() => updateFilters({ sort: s.value })}
                  className={`px-6 py-2 rounded-lg text-sm font-black transition-all whitespace-nowrap ${
                    sort === s.value 
                      ? "bg-blue-600 text-white shadow-lg shadow-blue-500/25" 
                      : "text-slate-500 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-800"
                  }`}
                >
                  {s.label}
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col gap-1.5 sm:gap-2">
            {products.map((product, index) => (
              <React.Fragment key={product._id}>
              {index === 4 && <SponsoredAdSlot position="home" />}
              {index === 12 && <SponsoredAdSlot position="between_ads" />}
              {/* Discovery banners - inserted after 10 and 20 products */}
                {index === 10 && (
                  <div className="col-span-1 mb-3 sm:mb-6">
                    <div className="flex flex-col items-center justify-between gap-5 rounded-3xl border border-white/10 bg-gradient-to-r from-emerald-600 to-teal-700 p-5 text-white shadow-xl shadow-emerald-500/20 sm:flex-row sm:p-6">
                      <div className="flex min-w-0 items-center gap-4">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/20">
                          <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2m6-10a4 4 0 100-8 4 4 0 000 8zm13-3h-6m3-3v6" />
                          </svg>
                        </div>
                        <div className="min-w-0">
                          <h3 className="mb-1 text-lg font-black sm:text-xl">كن سفيرًا لسوقك واربح من دعواتك</h3>
                          <p className="text-sm font-medium text-emerald-100">شارك رابطك الخاص واحصل على 10% من العمولات والرسوم المؤهلة</p>
                        </div>
                      </div>
                      <Link to="/referrals" className="w-full shrink-0 rounded-xl bg-white px-6 py-3 text-center font-black text-emerald-700 shadow-lg transition-all hover:scale-[1.02] active:scale-95 sm:w-auto">
                        اكتشف سفراء سوقك
                      </Link>
                    </div>
                  </div>
                )}
                {index === 20 && (
                  <div className="col-span-1 mb-3 sm:mb-6">
                    <div className="flex flex-col items-center justify-between gap-5 rounded-3xl border border-white/10 bg-gradient-to-r from-blue-600 to-indigo-700 p-5 text-white shadow-xl shadow-blue-500/20 sm:flex-row sm:p-6">
                      <div className="flex min-w-0 items-center gap-4">
                        <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-white/20">
                          <svg className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                          </svg>
                        </div>
                        <div className="min-w-0">
                          <h3 className="mb-1 text-lg font-black sm:text-xl">وجدت منتجًا خارج سوقك؟ اشتره بأمان</h3>
                          <p className="text-sm font-medium text-blue-100">اطلب من البائع إضافته إلى سوقك وأكمل الصفقة مع حماية الشراء الآمن</p>
                        </div>
                      </div>
                      <Link to="/secure-deal-explanation" className="w-full shrink-0 rounded-xl bg-white px-6 py-3 text-center font-black text-blue-700 shadow-lg transition-all hover:scale-[1.02] active:scale-95 sm:w-auto">
                        تعرّف على الشراء الآمن
                      </Link>
                    </div>
                  </div>
                )}
                <ProductCard
                  product={product}
                  to={`/ad/${product._id}/${product.slug || ""}`}
                  featured={product.featured}
                  governorateName={product.governorateId?.name}
                  cityName={product.cityId?.name}
                  prefetchAds={prefetchCategoryAds}
                  displayMode="list"
                />
              </React.Fragment>
            ))}
            
            {loading && [...Array(8)].map((_, i) => (
              <div key={i} className="animate-pulse flex flex-col gap-3">
                <div className="aspect-[4/3] bg-slate-200 dark:bg-slate-800 rounded-[32px]"></div>
                <div className="h-5 bg-slate-200 dark:bg-slate-800 rounded-full w-3/4"></div>
                <div className="h-4 bg-slate-100 dark:bg-slate-900 rounded-full w-1/2"></div>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-col items-center justify-center">
            {page < pages && !loading && (
              <button
                onClick={() => updateFilters({ page: page + 1 })}
                className="group relative flex items-center gap-3 px-12 py-4 bg-white dark:bg-slate-900 border-2 border-blue-600/20 dark:border-blue-900/50 rounded-2xl font-black text-blue-600 dark:text-blue-400 transition-all hover:bg-blue-600 hover:text-white hover:border-blue-600 hover:shadow-2xl hover:shadow-blue-500/30 active:scale-95 group"
              >
                <span>عرض المزيد من الإعلانات</span>
                <svg className="w-5 h-5 transition-transform group-hover:translate-y-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
                </svg>
              </button>
            )}

            {loading && page > 1 && (
              <div className="flex items-center gap-3 px-8 py-4 bg-blue-50 dark:bg-blue-900/20 rounded-2xl text-blue-600 dark:text-blue-400 font-black animate-pulse">
                <div className="flex gap-1">
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                  <div className="w-2 h-2 bg-current rounded-full animate-bounce"></div>
                </div>
                <span>جاري تحميل المزيد...</span>
              </div>
            )}
            
            {page >= pages && products.length > 0 && !loading && (
              <div className="text-slate-400 dark:text-slate-600 font-bold flex items-center gap-2">
                <div className="h-px w-8 bg-current opacity-20"></div>
                <span>لقد وصلت إلى نهاية القائمة</span>
                <div className="h-px w-8 bg-current opacity-20"></div>
              </div>
            )}
          </div>
        </section>
        </div>

        <section className="mb-10 overflow-hidden rounded-3xl bg-blue-50/70 px-4 py-5 text-center sm:mb-16 sm:px-8 sm:py-8 dark:bg-slate-900/60">
          <h3 className="text-lg font-black text-slate-900 dark:text-white sm:text-2xl">منصة سوقك لكل احتياجاتك</h3>
          <p className="mt-1 text-[11px] font-bold text-slate-500 dark:text-slate-400 sm:text-sm">كل ما تبحث عنه في مكان واحد</p>
          <img
            src="/main_picture.png"
            alt="منتجات متنوعة في منصة سوقك"
            className="mx-auto mt-3 w-full max-w-[330px] object-contain sm:mt-5 sm:max-w-[520px]"
            loading="lazy"
          />
        </section>

        {popularTags.length > 0 && (
          <section className="mb-10 rounded-3xl p-4 sm:mb-20 sm:rounded-[40px] sm:p-12 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2"></div>
            <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-between mb-4 sm:mb-8">
                <div>
                  <h3 className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white">الوسوم الرائجة الآن</h3>
                  <p className="text-[10px] sm:text-xs text-slate-500 dark:text-slate-400 font-bold uppercase tracking-wider mt-1">اكتشف ما يبحث عنه الجميع في اليمن</p>
                </div>
                <div className="hidden sm:flex items-center gap-2">
                  <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
                  <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">تحديث مباشر</span>
                </div>
              </div>

              <div className="flex flex-wrap gap-2 sm:gap-3">
                {popularTags.map((tag, i) => (
                  <button
                    key={tag._id}
                    onClick={() => navigate(`/search?tag=${tag.slug}`)}
                    className="group relative flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/50 border border-transparent hover:border-blue-500/30 hover:bg-white dark:hover:bg-slate-800 transition-all duration-300 hover:shadow-xl hover:shadow-blue-500/10"
                  >
                    <span className="text-blue-600 dark:text-blue-400 font-black text-sm sm:text-base">#</span>
                    <span className="text-slate-700 dark:text-slate-200 font-black text-sm sm:text-base">{tag.name}</span>
                    <span className="bg-white dark:bg-slate-700 px-1.5 py-0.5 rounded-md text-[9px] font-black text-slate-400 group-hover:text-blue-500 transition-colors">
                      {tag.count > 1000 ? `${(tag.count/1000).toFixed(1)}k` : tag.count}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </section>
        )}
      </main>

      <AdvancedSearchModal 
        isOpen={showAdvancedModal} 
        onClose={() => setShowAdvancedModal(false)} 
      />
      </div>
    </>
  );
}
