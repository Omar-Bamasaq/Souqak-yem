import React, { useState } from "react";
import { Link, useNavigate, useLocation } from "react-router-dom";
import { useAuth } from "../store/AuthContext.jsx";
import { t } from "../i18n/index.js";
import { useApi } from "../api/axios.js";
import Logo from "../components/Logo.jsx";
import { platformFeatures as features, PlatformFeaturesModal } from "../components/PlatformFeatures.jsx";

const iconSvg = (name) => {
  const icons = {
    shield: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />,
    cart: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 3h2l.4 2M7 13h10l4-8H5.4M7 13L5.4 5M7 13l-2.293 2.293c-.63.63-.184 1.707.707 1.707H17m0 0a2 2 0 100 4 2 2 0 000-4zm-8 2a2 2 0 11-4 0 2 2 0 014 0z" />,
    chat: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />,
    ads: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h7" />,
    review: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />,
    star: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z" />,
    badge: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" />,
    bell: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />,
    location: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />,
    heart: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" />,
    device: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />,
    cash: <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  };
  return icons[name] || icons.shield;
};

export default function Login() {
  const api = useApi();
  const [showPhonePassword, setShowPhonePassword] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();

  const [showFeatures, setShowFeatures] = useState(false);
  const [loginIdentifier, setLoginIdentifier] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginIdentifierErr, setLoginIdentifierErr] = useState("");
  const [loginPasswordErr, setLoginPasswordErr] = useState("");

  const validatePhoneLogin = () => {
    let ok = true;
    setLoginIdentifierErr("");
    setLoginPasswordErr("");
    if (!loginIdentifier.trim()) { setLoginIdentifierErr("اسم المستخدم أو رقم الهاتف مطلوب"); ok = false; }
    if (!loginPassword.trim()) { setLoginPasswordErr("كلمة المرور مطلوبة"); ok = false; }
    return ok;
  };

  const getDeviceType = () => {
    const ua = navigator.userAgent;
    if (/android/i.test(ua)) return "android";
    if (/iPhone|iPad|iPod/i.test(ua)) return "ios";
    if (/Windows/i.test(ua)) return "windows";
    if (/Macintosh/i.test(ua)) return "macos";
    return null;
  };

  const phoneLogin = async (e) => {
    e.preventDefault();
    if (!validatePhoneLogin()) return;
    setError("");
    setLoading(true);
    try {
      const res = await api.post("/auth/phone-login", {
        identifier: loginIdentifier.trim(),
        password: loginPassword,
        deviceType: getDeviceType()
      });

      if (res.data.requiresPasswordReset) {
        login(res.data.token, res.data.user);
        navigate("/set-new-password", { replace: true });
        return;
      }

      login(res.data.token, res.data.user);
      const from = location.state?.from?.pathname || (["admin", "supervisor"].includes(res.data.user?.role) ? "/admin" : "/");
      navigate(from, { replace: true });
    } catch (e2) {
      setError(e2?.response?.data?.error || "حدث خطأ أثناء تسجيل الدخول.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-slate-950 flex items-center justify-center p-0 sm:p-4 lg:p-6 relative overflow-hidden text-right" dir="rtl">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,_rgba(59,130,246,0.08)_0%,_transparent_50%)] pointer-events-none" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_bottom_left,_rgba(99,102,241,0.06)_0%,_transparent_50%)] pointer-events-none" />

      <div className="w-full max-w-5xl flex flex-col lg:flex-row gap-4 lg:gap-8 items-stretch relative z-10">
        <div className="hidden lg:flex lg:w-[52%] flex-col bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700 rounded-3xl p-8 xl:p-10 text-white shadow-xl shadow-blue-500/25 overflow-hidden relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-2xl" />
          <div className="absolute inset-0 bg-[url('data:image/svg+xml,%3Csvg%20width%3D%2260%22%20height%3D%2260%22%20viewBox%3D%220%200%2060%2060%22%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%3E%3Cg%20fill%3D%22none%22%20fill-rule%3D%22evenodd%22%3E%3Cg%20fill%3D%22%23ffffff%22%20fill-opacity%3D%220.04%22%3E%3Cpath%20d%3D%22M36%2034v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6%2034v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6%204V0H4v4H0v2h4v4h2V6h4V4H6z%22/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')] opacity-60" />
          <div className="relative z-10 flex flex-col h-full">
            <h3 className="text-2xl font-bold mb-2">{t("login.featuresTitle")}</h3>
            <p className="text-white/80 text-sm mb-6 shrink-0">كل ما تحتاجه لبيع وشراء آمن في اليمن</p>
            <div className="overflow-y-auto pr-2 custom-scrollbar space-y-4 max-h-[450px]">
              {features.map((f) => (
                <div key={f.key} className="flex items-start gap-3 p-3 rounded-2xl border border-white/10 bg-white/5 hover:bg-white/10 transition-all duration-200 group text-right">
                  <div className="w-9 h-9 rounded-xl bg-white/20 flex items-center justify-center flex-shrink-0 group-hover:bg-white/30 transition-colors">
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">{iconSvg(f.icon)}</svg>
                  </div>
                  <div className="min-w-0 flex-1">
                    <h4 className="font-semibold text-sm mb-0.5">{t(`login.features.${f.key}.title`)}</h4>
                    <p className="text-white/80 text-xs leading-relaxed">{t(`login.features.${f.key}.desc`)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="w-screen lg:w-[48%] flex flex-col items-center justify-center">
          <div className="w-screen max-w-none sm:w-full sm:max-w-md min-h-screen sm:min-h-0 bg-white/90 dark:bg-slate-900/90 rounded-none sm:rounded-[30px] border-0 sm:border border-slate-200/80 dark:border-slate-700/80 p-5 sm:p-8 lg:p-9 shadow-[0_30px_80px_rgba(15,23,42,0.08)] dark:shadow-[0_30px_70px_rgba(2,6,23,0.45)] backdrop-blur-md flex flex-col justify-center mx-auto">
            <div className="flex justify-center w-full mb-5 sm:mb-7">
              <Link to="/" className="hover:opacity-80 transition-opacity shrink-0">
                <div className="scale-100 sm:scale-100"><Logo iconSize="h-11 sm:h-12" /></div>
              </Link>
            </div>

            <div className="space-y-2 text-center mb-5 sm:mb-7 shrink-0">
              <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-gray-900 dark:text-slate-100">تسجيل الدخول</h1>
              <p className="text-xs sm:text-sm text-gray-600 dark:text-slate-300 px-2 leading-6">ادخل إلى حسابك الآن لإدارة إعلاناتك ومحادثاتك.</p>
              <div className="lg:hidden pt-2 sm:pt-4">
                <button onClick={() => setShowFeatures(true)} className="inline-flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full text-[10px] sm:text-xs font-bold border border-blue-100 dark:border-blue-800 transition-all active:scale-95">
                  <svg className="w-3.5 h-3.5 sm:w-4 sm:h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  {t("login.featuresTitle")}
                </button>
              </div>
            </div>

            <div className="custom-scrollbar pr-1 lg:overflow-y-auto lg:max-h-[500px]">
              {error && <div className="rounded-lg bg-red-50 border border-red-200 px-4 py-2 sm:py-3 text-xs sm:text-sm text-red-700 mb-4 font-medium text-center">{error}</div>}

              <form onSubmit={phoneLogin} className="space-y-3 sm:space-y-5">
                  <div>
                    <label className="block text-xs sm:text-sm text-gray-700 dark:text-slate-300 mb-1 sm:mb-2 font-semibold text-right">اسم المستخدم أو رقم الهاتف</label>
                    <input className="w-full rounded-xl border border-gray-300 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 px-3 py-2.5 sm:px-4 sm:py-3 text-xs sm:text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all text-right" placeholder="اسم المستخدم أو 7xxxxxxx" value={loginIdentifier} onChange={(e) => setLoginIdentifier(e.target.value)} required />
                    {loginIdentifierErr && <div className="mt-1 text-[10px] text-red-600 font-medium text-right">{loginIdentifierErr}</div>}
                  </div>
                  <div>
                    <div className="flex justify-between items-center mb-1 sm:mb-2">
                      <label className="block text-xs sm:text-sm text-gray-700 dark:text-slate-300 font-semibold text-right">كلمة المرور</label>
                      <Link to="/phone-forgot-password" title="استعادة كلمة المرور عبر الهاتف" className="text-[10px] sm:text-xs text-blue-600 hover:underline font-medium">هل نسيت كلمة المرور؟</Link>
                    </div>
                    <div className="relative">
                      <input type={showPhonePassword ? "text" : "password"} className="w-full rounded-xl border border-gray-300 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 px-3 py-2.5 pl-16 sm:px-4 sm:py-3 sm:pl-16 text-xs sm:text-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 focus:outline-none transition-all text-right" placeholder="••••••••" value={loginPassword} onChange={(e) => setLoginPassword(e.target.value)} required />
                      <button type="button" onClick={() => setShowPhonePassword(!showPhonePassword)} className="absolute inset-y-0 left-0 flex items-center pl-3 text-xs sm:text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors" aria-label={showPhonePassword ? "إخفاء كلمة المرور" : "إظهار كلمة المرور"} aria-pressed={showPhonePassword}>
                        {showPhonePassword ? "إخفاء" : "إظهار"}
                      </button>
                    </div>
                    {loginPasswordErr && <div className="mt-1 text-[10px] text-red-600 font-medium text-right">{loginPasswordErr}</div>}
                  </div>
                  <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-black py-3.5 sm:py-4 rounded-2xl shadow-lg shadow-blue-500/25 transition-all active:scale-[0.99] disabled:opacity-70 text-sm sm:text-base mt-2">
                    {loading ? "جاري الدخول..." : "دخول"}
                  </button>
              </form>

              <div className="text-center pt-4 sm:pt-6 border-t border-gray-100 dark:border-slate-700 shrink-0">
                <p className="text-gray-600 dark:text-slate-300 text-xs sm:text-sm">ليس لديك حساب؟ <Link to="/register" className="text-blue-600 font-bold hover:underline transition-all">سجل الآن</Link></p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {showFeatures && <PlatformFeaturesModal onClose={() => setShowFeatures(false)} />}
    </div>
  );
}
