import React, { useEffect, useRef, useState } from "react";
import { useApi } from "../api/axios.js";
import { useAuth } from "../store/AuthContext.jsx";
import { t } from "../i18n/index.js";
import CountdownTimer from "../components/CountdownTimer.jsx";
import BankAccountsDisplay from "../components/BankAccountsDisplay.jsx";
import { useSearchParams, Link } from "react-router-dom";
import { prepareFilesForUpload } from "../lib/imageCompression.js";
import CurrencyCalculator from "../components/CurrencyCalculator.jsx";
import { useDraftAction } from "../hooks/useDraftActions.js";

export default function Pricing() {
  const api = useApi();
  const { user } = useAuth();
  const userId = user?._id || user?.id;
  const [searchParams, setSearchParams] = useSearchParams();
  const draftAction = useDraftAction(api, userId, "featured_ad_upgrade");
  const [plans, setPlans] = useState([]);
  const [ads, setAds] = useState([]);
  const [banks, setBanks] = useState([]);
  const [selectedAd, setSelectedAd] = useState(searchParams.get("adId") || "");
  const [selectedPlan, setSelectedPlan] = useState(null);
  const [receiptFile, setReceiptFile] = useState(null);
  const [step, setStep] = useState(1);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);
  const [processingReceipt, setProcessingReceipt] = useState(false);
  const [trialEligibility, setTrialEligibility] = useState(null);
  const [showTrialModal, setShowTrialModal] = useState(false);
  const [activatingTrial, setActivatingTrial] = useState(false);
  const [success, setSuccess] = useState(false);
  const [draftStarted, setDraftStarted] = useState(false);
  const [referencesLoaded, setReferencesLoaded] = useState(false);
  const [resumedDraft, setResumedDraft] = useState(false);
  const submissionCompletedRef = useRef(false);

  const load = async () => {
    try {
      const [plansRes, eligibilityRes, bankRes] = await Promise.all([
        api.get("/plans"),
        api.get("/ads/welcome-promotion/eligibility"),
        api.get("/bank-accounts")
      ]);
      setPlans(plansRes.data);
      setTrialEligibility(eligibilityRes.data);
      setBanks(bankRes.data || []);
      
      if (user) {
        const my = await api.get("/ads/my?status=approved");
        setAds(my.data || []);
      }
    } catch (e) {
      setErr("فشل تحميل البيانات");
    } finally {
      setReferencesLoaded(true);
    }
  };

  useEffect(() => {
    load();
  }, [user]);

  useEffect(() => {
    const draftId = searchParams.get("draftActionId");
    if (!draftId || !referencesLoaded || !userId) return;
    let cancelled = false;
    (async () => {
      try {
        const draft = await draftAction.resume(draftId);
        if (cancelled) return;
        const plan = plans.find((item) => item._id === draft.planId && item.type === "featured");
        const ad = ads.find((item) => item._id === draft.adId);
        if (draft.type !== "featured_ad_upgrade"
          || !plan
          || !ad
          || draft.currentStep !== 2) {
          throw new Error("هذه العملية لم تعد متاحة بهذه البيانات. يمكنك بدء العملية من جديد.");
        }
        setSelectedPlan(plan);
        setSelectedAd(draft.adId);
        setStep(draft.currentStep);
        setDraftStarted(true);
        setResumedDraft(true);
        setSearchParams((current) => {
          const next = new URLSearchParams(current);
          next.delete("draftActionId");
          return next;
        }, { replace: true });
      } catch (resumeError) {
        if (!cancelled) setErr(resumeError.response?.data?.error || resumeError.message || "تعذر استئناف العملية.");
      }
    })();
    return () => { cancelled = true; };
  }, [ads, draftAction.resume, plans, referencesLoaded, searchParams, setSearchParams, userId]);

  useEffect(() => {
    if (submissionCompletedRef.current || !draftStarted || selectedPlan?.type !== "featured") return;
    draftAction.scheduleSave(2, {}, {
      adId: selectedAd || null,
      planId: selectedPlan._id
    });
  }, [draftAction.scheduleSave, draftStarted, selectedAd, selectedPlan]);

  const handleReceiptFileChange = async (e) => {
    const file = e.target.files?.[0];
    if (!file) {
      setReceiptFile(null);
      return;
    }

    try {
      setProcessingReceipt(true);
      const [prepared] = await prepareFilesForUpload([file], {
        maxSizeMB: 0.9,
        maxWidthOrHeight: 1800,
        initialQuality: 0.85,
      });
      setReceiptFile(prepared);
      setErr("");
    } catch (error) {
      console.error("Receipt compression failed:", error);
      setErr("تعذر تجهيز صورة السند. يرجى اختيار صورة أخرى أو صورة بحجم أصغر.");
      setReceiptFile(null);
    } finally {
      setProcessingReceipt(false);
    }
  };

  const activateTrial = async (adId) => {
    const targetAdId = adId || selectedAd;
    if (!targetAdId) {
      setErr("يجب اختيار إعلان لتجربة التمييز");
      return;
    }
    setActivatingTrial(true);
    setErr("");
    setMsg("");
    try {
      const res = await api.post("/ads/welcome-promotion/activate", { adId: targetAdId });
      setMsg(res.data.message);
      setShowTrialModal(false);
      load(); // Refresh eligibility
    } catch (e) {
      setErr(e.response?.data?.error || "تعذر تفعيل التجربة المجانية");
    } finally {
      setActivatingTrial(false);
    }
  };

  const getSaleIcon = (type) => {
    switch (type) {
      case 'flash_sale': return '⚡';
      case 'ramadan_offer': return '🌙';
      case 'eid_offer': return '🎉';
      case 'opening_offer': return '✨';
      default: return '🔥';
    }
  };

  const subscribe = async (plan) => {
    setMsg("");
    setErr("");
    
    if (!user) {
      setErr("قم بتسجيل الدخول للمتابعة");
      return;
    }

    if (plan.type === "featured" && !selectedAd) {
      setErr("يجب اختيار إعلان أولاً");
      return;
    }

    setSelectedPlan(plan);
    setStep(2);
    if (plan.type === "featured") setDraftStarted(true);
    // Scroll to top or step container
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmitRequest = async (e) => {
    e.preventDefault();
    setMsg("");
    setErr("");
    setLoading(true);

    try {
      const savedDraft = selectedPlan.type === "featured"
        ? await draftAction.persist(2, {}, {
          adId: selectedAd || null,
          planId: selectedPlan._id
        })
        : null;
      const draftActionId = savedDraft?._id || draftAction.draftId;
      const fd = new FormData();
      fd.append("planId", selectedPlan._id);
      if (selectedPlan.type === "featured") {
        fd.append("productId", selectedAd);
      }
      if (receiptFile) {
        fd.append("paymentReceipt", receiptFile);
      }
      if (selectedPlan.type === "featured" && draftActionId) fd.append("draftActionId", draftActionId);
      
      await api.post("/purchase-requests", fd, {
        headers: { "Content-Type": "multipart/form-data" }
      });
      
      submissionCompletedRef.current = true;
      if (selectedPlan.type === "featured" && draftActionId) draftAction.removeDraft(draftActionId);
      if (selectedPlan.type === "featured") draftAction.clear();
      setSuccess(true);
      setMsg(t("pricing.requestActivated"));
    } catch (e) {
      setErr(e.response?.data?.error || t("pricing.requestError"));
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="mx-auto max-w-2xl px-3 py-6 sm:px-4 sm:py-12">
        <div className="rounded-3xl bg-white border border-gray-100 p-6 text-center shadow-2xl shadow-blue-50 animate-in zoom-in duration-500 sm:rounded-[2.5rem] sm:p-10">
          <div className="mb-4 flex justify-center sm:mb-6">
            <div className="rounded-full bg-green-50 p-4 ring-8 ring-green-50/50">
              <svg className="h-12 w-12 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
              </svg>
            </div>
          </div>
          <h2 className="mb-4 text-3xl font-black text-gray-900">تم استلام طلبك بنجاح!</h2>
          <p className="mb-6 text-gray-600 font-bold leading-relaxed sm:mb-10">
            سيتم مراجعة طلب التمييز الخاص بك من قبل الإدارة وتفعيله في أقرب وقت ممكن.
          </p>
          <div className="flex flex-col gap-3">
            <Link
              to="/account"
              className="w-full rounded-2xl bg-blue-600 py-4 text-base font-black text-white transition-all hover:bg-blue-700 shadow-xl shadow-blue-100 active:scale-95"
            >
              العودة إلى حسابي
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl space-y-6 px-3 py-5 sm:space-y-12 sm:px-4 sm:py-12">
      {draftAction.error && <div role="alert" className="rounded-2xl border border-amber-200 bg-amber-50 p-4 text-sm font-bold text-amber-800">{draftAction.error}</div>}
      {resumedDraft && selectedPlan?.type === "featured" && <p className="rounded-2xl border border-blue-200 bg-blue-50 p-4 text-sm font-semibold text-blue-800">أعد رفع سند الدفع للمتابعة؛ لا تُحفظ الملفات ضمن العمليات غير المكتملة.</p>}
      {step === 1 && (
        <>
          <div className="text-center space-y-4">
            <h1 className="text-4xl font-black text-gray-900 tracking-tight">{t("pricing.title")}</h1>
            <p className="text-gray-500 font-medium max-w-2xl mx-auto">اختر الباقة المناسبة لاحتياجاتك وابدأ في تنمية أعمالك اليوم مع مميزات حصرية.</p>
          </div>

          {msg && (
            <div className="max-w-md mx-auto bg-green-50 border border-green-100 rounded-2xl p-4 flex items-center gap-3 text-green-700 animate-in fade-in zoom-in duration-300">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
              <p className="text-sm font-bold">{msg}</p>
            </div>
          )}

          {err && (
            <div className="max-w-md mx-auto bg-red-50 border border-red-100 rounded-2xl p-4 flex items-center gap-3 text-red-700 animate-in fade-in zoom-in duration-300">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              <p className="text-sm font-bold">{err}</p>
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3 sm:gap-8">
        {/* Welcome Promotion Trial Card */}
        {trialEligibility && (trialEligibility.eligible || trialEligibility.reason === "quota_full") && (
          <div className="relative group flex flex-col bg-gradient-to-br from-amber-400 to-orange-500 rounded-[2.5rem] border-4 border-white transition-all duration-500 hover:shadow-2xl hover:shadow-orange-100 hover:-translate-y-2 overflow-hidden shadow-xl">
            <div className="absolute top-0 left-0 w-full h-full opacity-10">
              <svg width="100%" height="100%"><pattern id="grid-p" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="white" strokeWidth="1"/></pattern><rect width="100%" height="100%" fill="url(#grid-p)" /></svg>
            </div>
            
            <div className="p-8 pt-12 flex-1 flex flex-col relative z-10 text-white">
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-3xl shadow-inner backdrop-blur-sm mx-auto mb-4">
                  🎁
                </div>
                <h3 className="text-xl font-black mb-2">تجربة مجانية</h3>
                <p className="text-orange-50 text-xs font-bold leading-relaxed">
                  ارفع إعلانك إلى أعلى النتائج لمدة {trialEligibility.durationHours || 6} ساعات مجاناً وشاهد الفرق في النتائج.
                </p>
              </div>

              <div className="bg-white/20 rounded-3xl p-6 mb-6 text-center border border-white/30 backdrop-blur-sm">
                <div className="text-3xl font-black">مجاناً</div>
                <div className="text-[10px] font-black text-orange-100 uppercase tracking-widest mt-1">
                  تجربة لمرة واحدة فقط
                </div>
              </div>

              {trialEligibility.eligible ? (
                <>
                  <div className="space-y-3 mb-6">
                    <div className="flex items-center gap-3 text-xs font-black bg-white/20 px-4 py-2 rounded-full">
                      <span className="animate-pulse">🔥</span>
                      متبقي {trialEligibility.remaining} تجربة مجانية فقط
                    </div>
                  </div>

                  <button 
                    onClick={() => setShowTrialModal(true)}
                    className="w-full mt-auto py-4 bg-white text-orange-600 rounded-[1.5rem] text-sm font-black hover:bg-orange-50 transition-all active:scale-95 shadow-xl flex items-center justify-center gap-2"
                  >
                    <span>ابدأ التجربة الآن</span>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                  </button>
                </>
              ) : (
                <div className="mt-auto p-4 bg-white/10 rounded-2xl border border-white/20 text-center backdrop-blur-sm">
                  <p className="text-sm font-black">انتهت جميع التجارب المجانية المتاحة حالياً.</p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Free Trial Ad Selection Modal */}
        {showTrialModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm animate-in fade-in duration-300">
            <div className="w-full max-w-md rounded-[2.5rem] bg-white shadow-2xl overflow-hidden animate-in zoom-in duration-300">
              <div className="bg-gradient-to-br from-amber-400 to-orange-500 p-6 text-center text-white">
                <div className="text-4xl mb-2">🎁</div>
                <h3 className="text-xl font-black">اختر الإعلان</h3>
                <p className="text-orange-50 text-xs font-bold">اختر الإعلان الذي تريد تمييزه مجاناً لمدة {trialEligibility.durationHours} ساعات</p>
              </div>
              <div className="p-6">
                <div className="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                  {ads.length > 0 ? ads.map(ad => (
                    <label 
                      key={ad._id}
                      className={`flex items-center gap-4 p-4 rounded-2xl border-2 cursor-pointer transition-all ${
                        selectedAd === ad._id ? "border-orange-500 bg-orange-50" : "border-gray-100 hover:border-orange-200"
                      }`}
                    >
                      <input 
                        type="radio" 
                        name="trialAdPricing" 
                        className="sr-only" 
                        checked={selectedAd === ad._id}
                        onChange={() => setSelectedAd(ad._id)}
                      />
                      {ad.images?.[0] && (
                        <img 
                          src={`${import.meta.env.VITE_API_URL}/uploads/${ad.images[0]}`} 
                          alt="" 
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                      )}
                      <div className="flex-1">
                        <p className="text-sm font-black text-gray-900 line-clamp-1">{ad.title}</p>
                        <p className="text-[10px] font-bold text-gray-400">{ad.price} {ad.currency}</p>
                      </div>
                      <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                        selectedAd === ad._id ? "border-orange-500 bg-orange-500" : "border-gray-300"
                      }`}>
                        {selectedAd === ad._id && <div className="w-2 h-2 bg-white rounded-full"></div>}
                      </div>
                    </label>
                  )) : (
                    <div className="text-center py-8">
                      <p className="text-gray-500 font-bold">لا توجد إعلانات معتمدة حالياً.</p>
                      <Link to="/add-product" className="text-blue-600 text-sm font-black mt-2 inline-block">أنشئ إعلانك الأول الآن</Link>
                    </div>
                  )}
                </div>

                <div className="mt-6 flex flex-col gap-2">
                  <button
                    onClick={() => activateTrial(selectedAd)}
                    disabled={!selectedAd || activatingTrial}
                    className="w-full py-4 bg-orange-500 text-white rounded-2xl font-black shadow-lg shadow-orange-100 hover:bg-orange-600 active:scale-95 disabled:opacity-50 transition-all"
                  >
                    {activatingTrial ? "جاري التفعيل..." : "تأكيد التفعيل المجاني"}
                  </button>
                  <button
                    onClick={() => setShowTrialModal(false)}
                    className="w-full py-3 bg-gray-50 text-gray-500 rounded-2xl text-xs font-bold hover:bg-gray-100 transition-all"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

            {plans.map((p) => {
              const isVerification = p.type === "verification";
              const gradientClass = isVerification 
                ? "from-emerald-500 to-teal-700" 
                : "from-blue-600 to-indigo-800";
              
              return (
                <div 
                  key={p._id} 
                  className={`relative group flex flex-col bg-gradient-to-br ${gradientClass} rounded-[2.5rem] border-4 border-white transition-all duration-500 hover:shadow-2xl hover:-translate-y-2 overflow-hidden shadow-xl text-white`}
                >
                  <div className="absolute top-0 left-0 w-full h-full opacity-10">
                    <svg width="100%" height="100%"><pattern id={`grid-${p._id}`} width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="white" strokeWidth="1"/></pattern><rect width="100%" height="100%" fill={`url(#grid-${p._id})`} /></svg>
                  </div>

                  {/* Badges */}
                  <div className="absolute top-4 inset-x-0 flex flex-col items-center gap-2 z-20">
                    {p.isMostPopular && (
                      <span className="bg-amber-300 text-amber-950 text-[10px] font-black px-4 py-1.5 rounded-full shadow-lg">
                        الأكثر طلبًا
                      </span>
                    )}
                    {p.isPopularOffer && (
                      <span className="bg-white text-blue-600 text-[10px] font-black px-4 py-1.5 rounded-full shadow-lg uppercase tracking-widest">
                        الأكثر شراءً
                      </span>
                    )}
                    {p.isSaleRunning && p.saleLabel && (
                      <span className="bg-orange-500 text-white text-[10px] font-black px-4 py-1.5 rounded-full shadow-lg uppercase tracking-widest flex items-center gap-1.5">
                        {getSaleIcon(p.saleType)} {p.saleLabel}
                      </span>
                    )}
                  </div>

                  <div className="p-8 pt-16 flex-1 flex flex-col relative z-10">
                    <div className="text-center mb-8">
                      <div className="w-16 h-16 bg-white/20 rounded-2xl flex items-center justify-center text-3xl shadow-inner backdrop-blur-sm mx-auto mb-4 border border-white/30">
                        {isVerification ? "🛡️" : "⭐"}
                      </div>
                      <h3 className="text-2xl font-black mb-1">{p.name}</h3>
                      <p className="text-[10px] font-black text-white/70 uppercase tracking-widest">
                        {isVerification ? t("pricing.typeVerification") : t("pricing.typeFeatured")}
                      </p>
                    </div>

                    {/* Price Section */}
                    <div className="bg-white/10 rounded-3xl p-6 mb-8 text-center border border-white/20 backdrop-blur-sm">
                      <div className="flex flex-col items-center justify-center gap-1">
                        {p.isSaleRunning ? (
                          <>
                            <div className="flex items-center gap-2">
                              <span className="text-white/50 text-sm font-bold line-through">
                                {p.originalPrice.toLocaleString()}
                              </span>
                              <span className="bg-orange-500 text-white text-[10px] font-black px-2 py-0.5 rounded-lg border border-orange-400">
                                وفر {p.discountPercent}%
                              </span>
                            </div>
                            <div className="flex items-baseline gap-1">
                              <span className="text-4xl font-black">{p.finalPrice.toLocaleString()}</span>
                              <span className="text-xs font-black text-white/70">{p.currency === "USD" ? "$" : p.currency === "SAR" ? "ر.س" : "ر.ي"}</span>
                            </div>
                          </>
                        ) : (
                          <div className="flex items-baseline gap-1">
                            <span className="text-4xl font-black">{p.price.toLocaleString()}</span>
                            <span className="text-xs font-black text-white/70">{p.currency === "USD" ? "$" : p.currency === "SAR" ? "ر.س" : "ر.ي"}</span>
                          </div>
                        )}
                      </div>
                      <div className="mt-2 text-[10px] font-black text-white/50 uppercase tracking-tighter">
                        صلاحية لمدة {p.durationInDays} يوم
                      </div>
                      <CurrencyCalculator
                        amount={p.isSaleRunning ? p.finalPrice : p.price}
                        currency={p.currency}
                      />
                    </div>

                    {/* Countdown Timer */}
                    {p.isSaleRunning && p.saleEndDate && (
                      <div className="mb-8">
                        <CountdownTimer endDate={p.saleEndDate} />
                      </div>
                    )}

                    {/* Features List */}
                    <div className="space-y-4 mb-8">
                      <div className="flex items-center gap-3 text-sm font-bold text-white/90">
                        <div className="w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center flex-shrink-0">
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                        </div>
                        {isVerification ? "علامة التوثيق المعتمدة" : "ظهور مميز في الصفحة الرئيسية"}
                      </div>
                      <div className="flex items-center gap-3 text-sm font-bold text-white/90">
                        <div className="w-6 h-6 rounded-full bg-white/20 text-white flex items-center justify-center flex-shrink-0">
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                        </div>
                        {isVerification ? "زيادة الثقة لدى المشترين" : "دعم فني سريع وأولوية في المراجعة"}
                      </div>
                      {p.remainingSlots > 0 && (
                        <div className="flex items-center gap-3 text-sm font-black text-orange-200 bg-white/10 p-3 rounded-2xl border border-white/20 animate-pulse">
                          <div className="w-5 h-5 rounded-full bg-orange-500 text-white flex items-center justify-center flex-shrink-0">
                            <span className="text-[10px]">⚠️</span>
                          </div>
                          بقي {p.remainingSlots} اشتراك فقط بهذا السعر
                        </div>
                      )}
                    </div>

                    {/* Ad Selection for Featured */}
                    {p.type === "featured" && (
                      <div className="mb-6">
                        <label className="block text-[10px] font-black text-white/50 mb-2 mr-1 uppercase tracking-wider">اختر الإعلان لتمييزه</label>
                        <select 
                          className="w-full px-4 py-3 bg-white/10 border border-white/20 rounded-2xl text-sm font-bold focus:ring-2 focus:ring-white/30 outline-none transition-all appearance-none cursor-pointer text-white backdrop-blur-sm"
                          value={selectedAd} 
                          onChange={(e) => setSelectedAd(e.target.value)}
                        >
                          <option value="" className="text-gray-900">-- اختر من إعلاناتك --</option>
                          {ads.map((ad) => (
                            <option key={ad._id} value={ad._id} className="text-gray-900">{ad.title}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Action Button */}
                    <button 
                      className={`w-full py-4 bg-white text-gray-900 rounded-[1.5rem] text-sm font-black transition-all duration-300 flex items-center justify-center gap-2 active:scale-95 shadow-xl hover:bg-gray-50 disabled:opacity-50 mt-auto`}
                      onClick={() => subscribe(p)}
                      disabled={loading}
                    >
                      {loading ? (
                        <div className="w-5 h-5 border-2 border-gray-900/30 border-t-gray-900 rounded-full animate-spin"></div>
                      ) : (
                        <>
                          <span>{t("pricing.subscribeNow")}</span>
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {step === 2 && selectedPlan && (
        <div className="max-w-3xl mx-auto space-y-5 sm:space-y-8 animate-in slide-in-from-bottom-8 duration-500">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => setStep(1)}
              className="flex items-center gap-2 text-sm font-bold text-gray-500 hover:text-blue-600 transition-colors"
            >
              <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 7l5 5m0 0l-5 5m5-5H6" /></svg>
              تغيير الباقة
            </button>
            <div className="flex items-center gap-2 text-xs font-black text-gray-400 uppercase tracking-widest">
              خطوة 2 من 2: الدفع
            </div>
          </div>

          <div className="bg-white rounded-[2.5rem] border border-gray-100 shadow-2xl overflow-hidden">
            <div className={`bg-gradient-to-br ${selectedPlan.type === 'verification' ? 'from-emerald-500 to-teal-700' : 'from-blue-600 to-indigo-800'} p-8 text-white text-center relative overflow-hidden`}>
              <div className="absolute top-0 left-0 w-full h-full opacity-10">
                <svg width="100%" height="100%"><pattern id="grid-step2" width="20" height="20" patternUnits="userSpaceOnUse"><path d="M 20 0 L 0 0 0 20" fill="none" stroke="white" strokeWidth="1"/></pattern><rect width="100%" height="100%" fill="url(#grid-step2)" /></svg>
              </div>
              <div className="relative z-10">
                <h2 className="text-2xl font-black mb-2">تفعيل باقة {selectedPlan.name}</h2>
                <div className="inline-block bg-white/20 backdrop-blur-md px-4 py-1.5 rounded-full text-sm font-black">
                  المبلغ المطلوب: {selectedPlan.isSaleRunning ? selectedPlan.finalPrice : selectedPlan.price} {selectedPlan.currency === "SAR" ? "ر.س" : selectedPlan.currency === "USD" ? "$" : "ر.ي"}
                </div>
              </div>
            </div>

            <form onSubmit={handleSubmitRequest} className="space-y-5 p-4 sm:space-y-8 sm:p-8">
              <div className="space-y-6">
                <div className="rounded-3xl border border-gray-100 bg-gray-50/50 p-6">
                  <h3 className="text-sm font-black text-gray-900 mb-6 flex items-center gap-2">
                    <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                    الحسابات البنكية المعتمدة
                  </h3>
                  <BankAccountsDisplay banks={banks} />
                </div>

                <div className="space-y-4">
                  <label className="block text-sm font-black text-gray-700">سند الدفع (صورة أو PDF)</label>
                  <div className="relative group">
                    <input
                      type="file"
                      accept=".jpg,.jpeg,.png,.pdf"
                      onChange={(e) => setReceiptFile(e.target.files?.[0] || null)}
                      required
                      className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                    />
                    <div className={`w-full py-10 border-4 border-dashed rounded-[2rem] flex flex-col items-center justify-center transition-all ${receiptFile ? 'border-green-200 bg-green-50' : 'border-gray-100 bg-gray-50/50 group-hover:border-blue-200 group-hover:bg-blue-50'}`}>
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center text-2xl mb-4 ${receiptFile ? 'bg-green-200 text-green-600' : 'bg-white shadow-sm text-gray-400'}`}>
                        {receiptFile ? "✅" : "📄"}
                      </div>
                      <p className="text-sm font-black text-gray-900">
                        {processingReceipt ? "جاري تجهيز السند..." : receiptFile ? receiptFile.name : "اضغط هنا لرفع سند الدفع"}
                      </p>
                      <p className="text-xs font-bold text-gray-400 mt-1">PNG, JPG, PDF (Max 5MB)</p>
                    </div>
                  </div>
                </div>
              </div>

              {err && (
                <div className="rounded-2xl bg-red-50 border border-red-100 p-4 flex items-center gap-3 text-red-700">
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  <p className="text-sm font-bold">{err}</p>
                </div>
              )}

              <button
                type="submit"
                disabled={loading || processingReceipt || !receiptFile}
                className="w-full py-5 bg-gray-900 text-white rounded-[1.5rem] text-base font-black shadow-2xl shadow-gray-200 hover:bg-black transition-all active:scale-95 disabled:opacity-50 flex items-center justify-center gap-3"
              >
                {loading ? (
                  <div className="w-6 h-6 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                ) : (
                  <>
                    <span>إرسال طلب التفعيل</span>
                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" /></svg>
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="text-center pt-8">
        <p className="text-gray-400 text-xs font-bold">جميع المعاملات تتم بشكل آمن ويتم مراجعتها من قبل الإدارة.</p>
      </div>
    </div>
  );
}
