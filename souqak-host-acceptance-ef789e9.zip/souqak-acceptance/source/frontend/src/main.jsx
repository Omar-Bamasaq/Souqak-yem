import React, { useEffect, useState } from "react";
import axios from "axios";
import { createRoot, hydrateRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { HelmetProvider } from "react-helmet-async";
import App from "./App.jsx";
import { IS_MAINTENANCE } from "./config/maintenance.js";
import { clearCsrfToken, ensureCsrfToken, isApiRequest } from "./api/csrf.js";
import { AuthProvider } from "./store/AuthContext.jsx";
import { ChatProvider } from "./store/ChatContext.jsx";
import { ThemeProvider } from "./store/ThemeContext.jsx";
import { BrokerageStatusProvider } from "./store/BrokerageStatusContext.jsx";
import { PublicSsgContent } from "./ssg/PublicSsgContent.mjs";
import { SsgDataProvider } from "./ssg/SsgDataContext.jsx";
import { resolveSiteBaseUrl } from "./lib/siteUrl.js";
import "./index.css";

const PRELOAD_RECOVERY_KEY = "souqak-preload-recovery";
const publicSiteBaseUrl = resolveSiteBaseUrl(import.meta.env.PUBLIC_SITE_URL);
const publicApiOrigin = (import.meta.env.VITE_API_URL || "https://api.souqak-yem.com/api")
  .replace(/\/api\/?$/, "");

axios.interceptors.request.use(async (config) => {
  if (IS_MAINTENANCE) {
    console.warn("[Maintenance] Blocking API request:", config.url || config.baseURL || "unknown");
    return Promise.reject(new Error("MAINTENANCE_MODE_ACTIVE"));
  }
  const method = config.method?.toLowerCase();
  if (
    ["post", "put", "patch", "delete"].includes(method) &&
    isApiRequest(config)
  ) {
    config.headers["X-CSRF-Token"] = await ensureCsrfToken();
  }
  return config;
}, (error) => Promise.reject(error));
axios.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.data?.code === "CSRF_TOKEN_INVALID") clearCsrfToken();
    return Promise.reject(error);
  }
);

window.addEventListener("vite:preloadError", (event) => {
  event.preventDefault();
  if (sessionStorage.getItem(PRELOAD_RECOVERY_KEY) === "1") return;
  sessionStorage.setItem(PRELOAD_RECOVERY_KEY, "1");
  window.location.reload();
});

window.addEventListener("load", () => {
  sessionStorage.removeItem(PRELOAD_RECOVERY_KEY);
});

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 10, // 10 minutes
      refetchOnWindowFocus: false,
      retry: 1,
    },
  },
});

const appTree = (
  <BrowserRouter future={{ v7_startTransition: true, v7_relativeSplatPath: true }}>
    <HelmetProvider>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
          <AuthProvider>
            <ChatProvider>
              <BrokerageStatusProvider>
                <SsgDataProvider value={window.__SOUQAK_SSG_DATA__}>
                  <App />
                </SsgDataProvider>
              </BrokerageStatusProvider>
            </ChatProvider>
          </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </HelmetProvider>
  </BrowserRouter>
);

function SsgAppTransition({ ssgData, app }) {
  const [showSsg, setShowSsg] = useState(true);

  useEffect(() => {
    setShowSsg(false);
  }, []);

  return showSsg ? (
    <PublicSsgContent
      kind={ssgData.kind}
      data={ssgData.data}
      siteBaseUrl={publicSiteBaseUrl}
      apiOrigin={publicApiOrigin}
    />
  ) : app;
}

const rootElement = document.getElementById("root");
const ssgData = window.__SOUQAK_SSG_DATA__;

if (ssgData && rootElement?.childNodes.length) {
  hydrateRoot(rootElement, <SsgAppTransition ssgData={ssgData} app={appTree} />);
} else {
  createRoot(rootElement).render(appTree);
}

// Keep the development server and HMR independent from the production PWA worker.
if ("serviceWorker" in navigator) {
  window.addEventListener("load", async () => {
    if (import.meta.env.PROD) {
      try {
        const registration = await navigator.serviceWorker.register("/sw.js");
        console.log("SW registered:", registration);
      } catch (error) {
        console.log("SW registration failed:", error);
      }
      return;
    }

    const registrations = await navigator.serviceWorker.getRegistrations();
    await Promise.all(registrations.map((registration) => registration.unregister()));
  });
}
