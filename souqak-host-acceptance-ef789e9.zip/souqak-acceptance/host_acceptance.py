#!/usr/bin/python3
"""Host acceptance only: no deployment, Docker, Nginx or production data operations."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import pwd
import shutil
import socket
import stat
import subprocess
import sys
import tempfile
from datetime import datetime, timezone, timedelta

COMMIT='ef789e9b5428f22057683a5311154eafab67d8cd'
BASE=Path('/var/lib/souqak-build-work')/('acceptance-'+COMMIT[:7])
PAYLOAD=Path(__file__).resolve().parent

def require(ok,message):
    if not ok:raise RuntimeError(message)

def protected(path):
    for item in (path,*path.parents):
        info=item.lstat()
        require(not stat.S_ISLNK(info.st_mode) and info.st_uid==0 and not info.st_mode&0o022,'Unprotected acceptance path: '+str(item))

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command,**kwargs):
    return subprocess.run(command,check=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=900,**kwargs)

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def fixture():
    now=datetime.now(timezone.utc);cat={'_id':'b'*24,'slug':'acceptance-only','name':'Acceptance fixture','description':'','image':None,'children':[]}
    return {'metadata':{'source':'host-acceptance-only','sourceDatabase':'no-database','sourceCommit':COMMIT,'schemaVersion':1,'siteBaseUrl':'https://souqak-yem.com','exportedAt':now.isoformat(),'expiresAt':(now+timedelta(days=1)).isoformat(),'maxAgeMs':86400000},'categories':[cat],'ads':[],'categorySsgDataBySlug':{cat['slug']:{'category':cat,'breadcrumbs':[],'subcategories':[],'ads':[]}}}

def scope(account,workspace,home,command,network=False):
    properties=['--quiet','--wait','--pipe','--collect','--uid=souqak-build',
      '--property=NoNewPrivileges=yes','--property=ProtectSystem=strict','--property=ProtectHome=yes',
      '--property=PrivateTmp=yes','--property=PrivateDevices=yes',
      *([] if network else ['--property=PrivateNetwork=yes','--property=IPAddressDeny=any']),
      '--property=CapabilityBoundingSet=',
      f'--property=ReadWritePaths={workspace} {home}',f'--property=WorkingDirectory={workspace}',
      '--property=InaccessiblePaths=-/home/souqak/deploy/souqak']
    return run(['systemd-run',*properties,'env','-i','PATH=/usr/local/bin:/usr/bin:/bin',f'HOME={home}','CI=1',*command])

def root_report(data):
    # Report lives in a root-only directory; builder output/logs cannot forge it.
    folder=BASE/'report';folder.mkdir(mode=0o700,exist_ok=True)
    temporary=folder/'report.tmp'
    with temporary.open('x') as output:
        json.dump(data,output,indent=2);output.write('\n');output.flush();os.fsync(output.fileno())
    temporary.chmod(0o600);os.replace(temporary,folder/'report.json')

def acceptance(cache_seed,warm_cache=False):
    require(os.geteuid()==0,'Use an administrative root session')
    protected(Path(__file__));protected(BASE.parent)
    index=json.loads((PAYLOAD/'payload-index.json').read_text())
    for relative,expected in index.items():
        file=PAYLOAD/relative;protected(file)
        require(file.is_file() and digest(file)==expected,'Payload identity mismatch: '+relative)
    account=pwd.getpwnam('souqak-build')
    require(account.pw_uid!=0 and set(os.getgrouplist('souqak-build',account.pw_gid))=={account.pw_gid},'Builder must be unprivileged without supplementary groups')
    require(account.pw_shell in ('/usr/sbin/nologin','/sbin/nologin','/bin/false'),'Builder must be non-login')
    BASE.mkdir(mode=0o711) # exclusive; never delete/reuse an earlier acceptance run
    result={'schema':1,'commit':COMMIT,'passed':False,'checks':{},'started_at':datetime.now(timezone.utc).isoformat()}
    try:
        tools=BASE/'tools';tools.mkdir(mode=0o700)
        manifest=json.loads((PAYLOAD/'manifest.json').read_text())
        for name,expected in manifest['original_sha256'].items():
            original=Path('/usr/local/libexec/souqak')/name;protected(original)
            require(digest(original)==expected,'Installed baseline changed: '+name)
            shutil.copyfile(original,tools/name)
        shutil.copyfile(PAYLOAD/'snapshot_contract.py',tools/'snapshot_contract.py')
        require(digest(tools/'snapshot_contract.py')==manifest['supporting_module_sha256'],'Snapshot module hash mismatch')
        for name,expected in manifest['patched_sha256'].items():
            run(['patch','--batch','--fuzz=0','-p1','-i',str(PAYLOAD/(name+'.patch'))],cwd=tools)
            require(digest(tools/name)==expected,'Patched identity mismatch')
        sys.path.insert(0,str(tools))
        engine=load('acceptance_engine',tools/'activate-release.py')
        prep=load('acceptance_preparer',tools/'prepare-update.py')
        # Read only directory metadata to ensure the isolated rename probe uses
        # the same filesystem as actual publication; never write in those paths.
        publication_device=engine.STAGING_ROOT.stat().st_dev
        require(publication_device==engine.PREPARED_ROOT.stat().st_dev==BASE.stat().st_dev,'Publication/test filesystems differ; atomic publication needs a separate same-filesystem acceptance')
        result['checks']['publication_filesystem_match']=True
        # All mutable constants are redirected before calling any helper function.
        engine.STATE_ROOT=BASE/'state';engine.STATE_ROOT.mkdir(mode=0o700)
        engine.STAGING_ROOT=BASE/'staging';engine.STAGING_ROOT.mkdir(mode=0o700)
        engine.PREPARED_ROOT=BASE/'prepared';engine.PREPARED_ROOT.mkdir(mode=0o700)
        submitter=pwd.getpwnam('souqak')
        os.chown(engine.PREPARED_ROOT,submitter.pw_uid,submitter.pw_gid)
        engine.BUILD_ROOT=BASE
        source=BASE/'source';source.mkdir(mode=0o700)
        shutil.copytree(PAYLOAD/'source/frontend',source/'frontend')
        (source/'backend').mkdir();shutil.copyfile(PAYLOAD/'source/backend/package.json',source/'backend/package.json');shutil.copyfile(PAYLOAD/'source/backend/package-lock.json',source/'backend/package-lock.json')
        home=BASE/'home';home.mkdir(mode=0o700)
        workspace=BASE/'workspace';workspace.mkdir(mode=0o700)
        # Copy only integrity-addressed package artifacts, never npm config/tokens.
        cache=home/'.npm';cache.mkdir()
        if not warm_cache:
            seed=Path(cache_seed)/'_cacache'
            require(seed.is_dir(),'No usable cache seed; use --warm-cache for connected artifact-only staging')
            target=cache/'_cacache';target.mkdir(mode=0o700)
            # Walk from / with no-follow directory descriptors; an unprivileged
            # cache owner cannot redirect root copying through a symlink.
            fd=os.open('/',os.O_RDONLY|os.O_DIRECTORY)
            try:
                for part in seed.absolute().parts[1:]:
                    child=os.open(part,os.O_RDONLY|os.O_DIRECTORY|os.O_NOFOLLOW,dir_fd=fd)
                    os.close(fd);fd=child
                engine._copy_build_directory(fd,target,[0])
            finally:os.close(fd)
        for directory in (home,workspace):
            for path in [*sorted(directory.rglob('*'),key=lambda p:len(p.parts),reverse=True),directory]:
                os.chown(path,account.pw_uid,account.pw_gid,follow_symlinks=False)
        if warm_cache:
            for component in ('frontend','backend'):
                target=workspace/('warm-'+component);target.mkdir()
                for name in ('package.json','package-lock.json'):
                    shutil.copyfile(source/component/name,target/name)
                os.chown(target,account.pw_uid,account.pw_gid)
                scope(account,workspace,home,['npm','ci','--prefix',str(target),'--ignore-scripts','--strict-ssl=true','--cache',str(cache),'--no-audit','--no-fund'],network=True)
            result['cache_mode']='connected artifacts only, then offline validation'
        else:
            result['cache_mode']='isolated copy of existing integrity-addressed artifacts'
        # A private root canary is a fixture, not the production environment file.
        canary=engine.STATE_ROOT/'root-canary';canary.write_text('acceptance-only');canary.chmod(0o600)
        with socket.socket() as listener:
            listener.bind(('127.0.0.1',0));listener.listen()
            code="""import os,socket,sys
assert os.geteuid()==int(sys.argv[1])
assert os.readlink('/proc/self/ns/net')!=sys.argv[2]
assert 'NoNewPrivs:\\t1' in open('/proc/self/status').read()
try: open(sys.argv[3]).read()
except PermissionError: pass
else: raise RuntimeError('root canary readable')
try: ds=os.stat('/var/run/docker.sock')
except FileNotFoundError: pass
else:
 perms=(ds.st_mode>>6)&7 if ds.st_uid==os.geteuid() else ((ds.st_mode>>3)&7 if ds.st_gid in [os.getegid(),*os.getgroups()] else ds.st_mode&7)
 assert not perms&2, 'builder has Docker socket write permission'
s=socket.socket();s.settimeout(2)
assert s.connect_ex(('127.0.0.1',int(sys.argv[4])))!=0
print('sandbox-probe-passed')
"""
            scope(account,workspace,home,['python3','-c',code,str(account.pw_uid),os.readlink('/proc/self/ns/net'),str(canary),str(listener.getsockname()[1])])
        result['checks']['systemd_identity_network_permissions']=True
        result['runtime']={name:scope(account,workspace,home,[name,'--version']).stdout.decode().strip() for name in ('node','npm')}
        scope(account,workspace,home,['npm','cache','verify','--cache',str(cache)])
        backend=workspace/'backend';backend.mkdir()
        for name in ('package.json','package-lock.json'):shutil.copyfile(source/'backend'/name,backend/name)
        os.chown(backend,account.pw_uid,account.pw_gid)
        scope(account,workspace,home,['npm','ci','--offline','--prefix',str(backend),'--no-audit','--no-fund'])
        result['checks']['backend_npm_offline']=True
        snapshot=BASE/'fixture-snapshot.json';snapshot.write_text(json.dumps(fixture()));snapshot.chmod(0o600)
        info=engine.snapshot_info(snapshot,COMMIT)
        engine.seo_receipt(COMMIT,info,create=True)
        engine.seo_receipt(COMMIT,info)
        try:engine.seo_receipt(COMMIT,{**info,'sha256':'0'*64})
        except engine.DeploymentError:pass
        else:raise RuntimeError('Forged receipt accepted')
        receipt=engine.STATE_ROOT/'seo-receipts'/(COMMIT+'.json')
        scope(account,workspace,home,['python3','-c',"import os,sys;assert not os.access(sys.argv[1],os.R_OK|os.W_OK)",str(receipt)])
        result['checks']['protected_snapshot_receipt']=True
        # Actual patched helper: real systemd, offline npm, Node validator, Vite + SEO.
        # Redirect HOME/cache only; UID/GID are the real builder account.
        from types import SimpleNamespace
        test_account=SimpleNamespace(pw_uid=account.pw_uid,pw_gid=account.pw_gid,pw_dir=str(home))
        actual_run=engine.run
        def guarded_run(command,**kwargs):
            require(command[0]=='systemd-run','Unexpected acceptance subprocess')
            require('--property=PrivateNetwork=yes' in command,'Build network isolation absent')
            return actual_run(command,**kwargs)
        engine.run=guarded_run
        build_workspace=BASE/'frontend-build';build_workspace.mkdir(mode=0o700)
        dist=engine.build_frontend_as_builder(source,build_workspace,test_account,snapshot,COMMIT,info)
        result['checks']['frontend_real_offline_seo_build']=True
        # Validate the generated SEO output as builder, with the same sandbox.
        scope(account,build_workspace,home,['node',str(build_workspace/'frontend/scripts/prerenderBuild.mjs'),'--validate',str(dist)])
        result['checks']['seo_output_validation']=True
        # Secure-copy Snapshot input into a builder-workspace directory, as prepare expects.
        seo=BASE/'seo';seo.mkdir(mode=0o700);shutil.copyfile(snapshot,seo/'seo-snapshot.json')
        # Receipt already exists: test publication independently without minting another.
        original_receipt=engine.seo_receipt
        def existing_receipt(release,expected,create=False):return original_receipt(release,expected)
        engine.seo_receipt=existing_receipt
        prep.activation_library=lambda:engine
        bundle=prep.create_release_bundle(COMMIT,dist,seo/'seo-snapshot.json')
        require(bundle.is_dir(),'Bundle publication failed')
        destination=BASE/'copy';destination.mkdir(mode=0o700)
        engine.snapshot_bundle(bundle,destination,COMMIT,pwd.getpwnam('souqak').pw_uid)
        saved=digest(bundle/'manifest.json')
        try:prep.create_release_bundle(COMMIT,dist,seo/'seo-snapshot.json')
        except RuntimeError:pass
        else:raise RuntimeError('Existing bundle overwrite accepted')
        require(digest(bundle/'manifest.json')==saved,'Existing bundle changed')
        # Probe renameat2 directly onto an occupied destination to exercise the syscall.
        import ctypes
        a=BASE/'rename-probe';a.mkdir();b=BASE/'occupied';b.mkdir();(b/'keep').write_text('keep')
        libc=ctypes.CDLL(None,use_errno=True);rename=libc.renameat2
        rename.argtypes=[ctypes.c_int,ctypes.c_char_p,ctypes.c_int,ctypes.c_char_p,ctypes.c_uint]
        require(rename(-100,os.fsencode(a),-100,os.fsencode(b),1)==-1 and ctypes.get_errno()==17,'No-replace rename not enforced')
        require((b/'keep').read_text()=='keep','Atomic publication modified occupied target')
        result['checks']['secure_bundle_and_atomic_no_replace']=True
        result['passed']=True
    except Exception as error:
        # Do not expose captured npm logs, environment or production tool output.
        result['failure_type']=type(error).__name__
        result['next_action']='Inspect this isolated workspace as administrator; do not deploy or bypass the failed check.'
        root_report(result)
        raise RuntimeError('Acceptance failed: '+type(error).__name__+'; report: '+str(BASE/'report/report.json')) from None
    root_report(result)
    print('ACCEPTANCE PASSED (not deployment approval): '+str(BASE/'report/report.json'))

def verify():
    protected(Path(__file__));file=BASE/'report/report.json';protected(file)
    result=json.loads(file.read_text())
    expected={'publication_filesystem_match','systemd_identity_network_permissions','backend_npm_offline','protected_snapshot_receipt','frontend_real_offline_seo_build','seo_output_validation','secure_bundle_and_atomic_no_replace'}
    require(result.get('commit')==COMMIT and result.get('passed') is True and set(result.get('checks',{}))==expected and all(result['checks'].values()),'Acceptance incomplete or failed')
    print(json.dumps({'commit':COMMIT,'checks':result['checks'],'result':'PASS','production_activation':'NOT_RUN'},indent=2))

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('action',choices=['run','verify']);parser.add_argument('--cache-seed',default='/var/lib/souqak-build/.npm');parser.add_argument('--warm-cache',action='store_true');args=parser.parse_args()
    try:
        if args.action=='run':acceptance(args.cache_seed,args.warm_cache)
        else:verify()
    except Exception as error:
        print(str(error),file=sys.stderr);sys.exit(1)
