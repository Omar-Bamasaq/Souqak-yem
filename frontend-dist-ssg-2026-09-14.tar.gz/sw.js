const CACHE_NAME = "suqaq-pwa-v6";
const ASSETS_TO_CACHE = [
  "/favicon.svg",
  "/icon-cart.svg",
  "/manifest.json"
];

// Install Event - Pre-cache critical assets
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Pre-caching assets...");
      return cache.addAll(ASSETS_TO_CACHE);
    })
  );
  self.skipWaiting();
});

// Activate Event - Clean up old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
      );
    })
  );
  self.clients.claim();
});

// Fetch Event
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);

  // 1. Skip non-GET requests, API, and Socket.io
  if (
    event.request.method !== "GET" || 
    url.pathname.startsWith("/api") || 
    url.pathname.startsWith("/socket.io") ||
    url.origin !== self.location.origin
  ) {
    return;
  }

  // Cache only versioned JavaScript and CSS files, never the app shell.
  const isVersionedAsset = url.pathname.startsWith("/assets/") && /\.(js|css)$/.test(url.pathname);
  if (isVersionedAsset) {
    event.respondWith(
      caches.open(CACHE_NAME).then(async (cache) => {
        const cachedResponse = await cache.match(event.request);
        if (cachedResponse) return cachedResponse;

        try {
          const networkResponse = await fetch(event.request);
          const contentType = networkResponse.headers.get("content-type") || "";
          const isJavaScript = url.pathname.endsWith(".js") && /javascript|ecmascript/i.test(contentType);
          const isStylesheet = url.pathname.endsWith(".css") && /text\/css/i.test(contentType);
          if (networkResponse.ok && (isJavaScript || isStylesheet)) {
            await cache.put(event.request, networkResponse.clone());
          }
          return networkResponse;
        } catch {
          return new Response("Asset unavailable", {
            status: 503,
            statusText: "Asset Unavailable",
            headers: { "Content-Type": "text/plain; charset=utf-8" }
          });
        }
      })
    );
    return;
  }

  // Always fetch navigations first so the app shell cannot become stale.
  if (event.request.mode === "navigate") {
    event.respondWith(
      fetch(event.request).catch(() =>
        new Response("Offline", {
          status: 503,
          statusText: "Offline",
          headers: { "Content-Type": "text/plain; charset=utf-8" }
        })
      )
    );
  }
});

// Push Event - Handle incoming push notifications
self.addEventListener("push", (event) => {
  let data = {};
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: "سوقك", body: event.data.text() };
    }
  }

  const title = data.title || "سوقك";
  const options = {
    body: data.body || "",
    icon: data.icon || "/pwa/icon-192x192.png",
    badge: data.badge || "/pwa/icon-96x96.png",
    silent: data.silent === true,
    vibrate: Array.isArray(data.vibrate) ? data.vibrate : [100, 50, 100],
    data: {
      url: data.data?.url || "/",
      ...data.data
    },
    actions: [
      { action: "open", title: "عرض الآن" },
      { action: "close", title: "إغلاق" }
    ],
    // Ensure notification stays until interacted with (good for important alerts)
    requireInteraction: true 
  };

  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// Notification Click Event - Handle user interaction
self.addEventListener("notificationclick", (event) => {
  const notification = event.notification;
  const action = event.action;

  notification.close();

  if (action === "close") return;

  const urlToOpen = notification.data?.url || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((windowClients) => {
      // If a window is already open with the same URL, focus it
      for (let client of windowClients) {
        if (client.url === urlToOpen && "focus" in client) {
          return client.focus();
        }
      }
      // Otherwise, open a new window
      if (self.clients.openWindow) {
        return self.clients.openWindow(urlToOpen);
      }
    })
  );
});
